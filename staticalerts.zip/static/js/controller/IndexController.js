'use strict';

var IndexController = angularApp
		.controller(
				'IndexController',
				function IndexController($scope, $stateParams, $rootScope,
						$state, $http, $location, $window,$route, UserDataService,
						UtilService, ControllerService, siteId,
						CommonDataService,LatestCreatedService) {
					
					 
					$scope.alfrescoContext = UtilService.alfrescoContextRoot();
					$scope.token = sessionStorage.getItem('token');
					
					alert("IndexController controller page load"); 
				
					$scope.onLogoutClick = function() {
						alert("IndexController controller onLogoutClick"); 
						var method = 'delete';
						var url = "http://edelbsgcorpuat1.edelcap.com:8080"
								+ "/alfresco/api/-default-/public/authentication/versions/1/tickets/-me-"
						var headers = {
//							authorization : "Basic "
//									+ btoa(sessionStorage.getItem('token'))
							
							withCredentials : true 
							
						}
						var body = {};

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						})
								.then(function successCallback(response) {
											console.log("Logged out Successfully with response  : ",response);
											// $http.get(UtilService.contextRoot()
											// + '/logout', {})
											// var data=response.data;
											// console.log("Logged out
											// Successfully ", response.status);
											$rootScope.authenticated = false;
											/*$location.reload();*/
											$location.path("/login");
											$window.location.reload();

										},
										function errorCallback(response) {
											console.log("response  : ",response);
										});
						/*
						 * $http.get(UtilService.contextRoot() + '/login', {})
						 * .success(function () { $rootScope.authenticated =
						 * false; $location.path("/login"); }).error(function
						 * (data) { console.log("Logout failed")
						 * $rootScope.authenticated = false;
						 * $location.path("/login"); });
						 */

					}

				
					
				if ($rootScope.authenticated) {
						$('#overlay').modal('show');
						setTimeout(function() {
							$('#overlay').modal('hide');
						}, 5000);
						$state.go('mostraed');
					}
					/*
					 * if ($rootScope.authenticated) {
					 * $(window).load(function(){ $('#onload').modal('show');
					 * });
					 * 
					 * var n = $(".slider-slide-wrap").length, width = 194,
					 * newwidth = width * n;
					 * 
					 * $('.slide-wrap').css({ 'width': newwidth });
					 * 
					 * $(".slider-slide-wrap").each(function (i) { var thiswid =
					 * 194; $(this).css({ 'left': thiswid * i });
					 * 
					 * }); on scroll move the indicator 'shown' class to the
					 * most visible slide on viewport
					 * 
					 * $('.slider-wrap').scroll(function () { var scrollLeft =
					 * $(this).scrollLeft();
					 * $(".slider-slide-wrap").each(function (i) { var posLeft =
					 * $(this).position().left var w = $(this).width();
					 * 
					 * if (scrollLeft >= posLeft && scrollLeft < posLeft + w) {
					 * $(this).addClass('shown').siblings().removeClass('shown'); }
					 * }); }); on left button click scroll to the previous
					 * sibling of the current visible slide
					 * $('#slider-left').click(function () { var $prev =
					 * $('.slide-wrap .shown').prev();
					 * 
					 * if ($prev.length) { $('.slider-wrap').animate({
					 * scrollLeft: $prev.position().left }, 'slow'); } }); on
					 * right button click scroll to the next sibling of the
					 * current visible slide $('#slider-right').click(function () {
					 * var $next = $('.slide-wrap .shown').next();
					 * 
					 * if ($next.length) { $('.slider-wrap').animate({
					 * scrollLeft: $next.position().left }, 'slow'); } });
					 */

					$scope.onFeedbackSubmitCommentClick = function() {
						alert("IndexController controller onFeedbackSubmitCommentClick"); 
						// document.getElementById("myModal").close();

						if (sessionStorage.getItem('token')) {
							var text = $scope.feedbackText;
							var feedbackType = $scope.feedbackDropdownSelectedOption.name;
							

							if (text != null || text != undefined || text != ''	|| text != "") {
								var urlOnPage = $location;
								var userId = sessionStorage.getItem('userId');
								var method = 'post';
								var url = "http://edelbsgcorpuat1.edelcap.com:8080"+ "/api/feedback";
								text = text.trim();
								var body = {
									"username" : String(userId),
									"url" : String(urlOnPage.$$absUrl),
									"feedbackText" : "'"+ String(text) + "' Feedback From : " + String(userId),
									"feedbackType" : String(feedbackType)
								};

								var headers = {
									'Content-Type' : 'application/json'
								}

								$http({
									method : method,
									url : url,
									headers : headers,
									data : body
								}).then(function successCallback(response) {
									
									alert("IndexController controller successCallback"); 
									console.log(response);
									if (response.status === 200) {
										alert("IndexController controller status 200"); 
										console.log('status 200');
										console.log('response 200:  ',response.data.feedbackText);
										var feed = response.data.feedbackText;
										if(feed != null || feed != undefined || feed != '' || feed !=""){
																						
											$("[data-dismiss=modal]").trigger({ type: "click" });
											//document.getElementById("myForm").reset();
											
											/*$timeout(function () {
												$scope.successMessage = false;
									             window.location = '#/homeEtlife';
									        }, 5000);*/
											
											$scope.feedbackText = null;
											
										}else {
											alert("IndexController controller else"); 
											console.log(' Please enter text');
										}
									} else {
										alert("IndexController controller status othr then 200"); 
										console.log('status != 200');
									}
								}, function errorCallback(response) {
									alert("IndexController controller status error"); 
									console.log('error', response);
								});
							}
							//$scope.feedbackText = '';
							$scope.feedbackDropdownSelectedOption = $scope.feedbackDropdownOptions[0];
							document.getElementById("#myModal");

						} else {
							state.go('.myModel');
						}

						// $scope("#myModel").hide();
						// $('myModel').modal('hide');
						// document.getElementById("#myModal").close();
						//$scope.feedbackText = null;

					}

					$scope.onMainSearchClick = function() {
						alert("IndexController controller onMainSearchClick"); 
						var text = $scope.mainSearchText;
						$scope.selectedMenuItem = '';
						$state.go('search', {
							term : text
						});

						$scope.mainSearchText = null;

					}// close of onMainSearchClick()

					/*
					 * var input=$scope.mainSearchId;
					 * 
					 * 
					 * input.addEventListener("keyup", function(event) {
					 * event.preventDefault(); if (event.keyCode === 13) {
					 * console.log("+++++++++++++++++on Enter click");
					 * //document.getElementById("myBtn").click(); } });
					 */

					$scope.myFunct = function(keyEvent) {
						alert("IndexController controller myFunct"); 
						if (keyEvent.which === 13)
							$scope.onMainSearchClick();

						// $scope.mainSearchId = null;

					}

					$scope.onAboutUsClick = function() {

					}

					$scope.onSubscribeClick = function() {

					}

					var initilizeFeedbackDropdown = function() {
						alert("IndexController controller initilizeFeedbackDropdown"); 
						$scope.feedbackDropdownOptions = [ {
							name : "I like something",
							id : 1
						}, {
							name : "I dislike something",
							id : 2
						}, {
							name : "I have a suggestion",
							id : 3
						} ];
						$scope.feedbackDropdownSelectedOption = $scope.feedbackDropdownOptions[0];
					};

					/*
					 * var closeSelf =function(){ // do something
					 * 
					 * if(condition satisfied){ alert("conditions satisfied,
					 * submiting the form.");
					 * document.forms['certform'].submit(); window.close();
					 * }else{ alert("conditions not satisfied, returning to
					 * form"); } }
					 */
					
					//MostRead Start
					
	//Shreyas
					
					var getAllItems = function() {
						alert("IndexController controller getAllItems"); 
						//var nodeId = $stateParams.id;

						var payload = {'cmisaction': "query", 
							       'statement': "SELECT * FROM cmis:document WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') ORDER BY cmis:creationDate DESC",
							       'maxItems':100,
							       'skipCount':0,};
				    
						$.ajax({

					    url : "http://edelbsgcorpuat1.edelcap.com:8080" + '/alfresco/api/-default-/public/cmis/versions/1.1/browser',
					    type : 'POST',
					    xhrFields: {
					        'withCredentials': true //Tell browser to provide credentials
					    },
					    data: payload,
					    crossDomain: true,
					    success : function(data) {			
					    	
							if (data.results.length > 0) {
								
								    var listOfItems = data.results;
									
								} else {
									console.log('0 items in repository');
								}
								
							$scope.allItemsDetails = LatestCreatedService.getCmisPropertiesOf(data);
												    	
					    },
					    error : function(request,error)
					    {
					    	console.log('error');
							$state.go('login');
					    }
					  });

					}
					
					
					
//					var getAllItems = function() {
//
//						var method = 'post';
//						var url = UtilService.alfrescoContextRoot()
//						+ "/alfresco/api/-default-/public/search/versions/1/search";
//						/*+ "/alfresco/s/share-stats/select-audits?type=mostread&module=document&sites="
//						+ siteId + "&limit=1000";*/
//						var body = {
//								"query" : {
//									"query" : "SITE:'" + siteId + "' AND (*)", // \"corporate-controller-bpri\"
//									"language" : "afts"
//								},
//								"paging" : {
//									"maxItems" : 100,
//									"skipCount" : 0
//								},
//								"include" : [ "properties" ],
//								/* "path" */
//								/* "aspectNames" */
//								"filterQueries" : [ {
//									"query" : "TYPE:'cm:content'"
//								}, {
//									"query" : "-cm:creator:system"
//								}, {
//									"query" : "-TYPE:'fm:post'"
//								} ],
//							
//							"sort" : [ {
//								"type" : "FIELD",
//								/*"field" : "cm:mimeType", commented by sandeep*/
//								"field" : "cm:created",
//								/*"field" : "cm:modified", commented by sandeep*/
//								/*"ascending" : "true"*/
//								"ascending" : "false"
//							} ],
//							'defaults' : {
//								'textAttributes' : [ 'cm:content', 'cm:name',
//										'cm:description', 'cm:title' ],
//								'defaultFTSOperator' : 'OR',
//								'defaultFTSFieldOperator' : 'OR',
//								'namespace' : 'cm',
//								'defaultFieldName' : '\"/\"'
//							}
//						};
//
//						var headers = {
//							authorization : "Basic "
//									+ btoa(sessionStorage.getItem('token'))
//						}
//
//						$http({
//							method : method,
//							url : url,
//							headers : headers,
//							data : body
//						})
//								.then(function successCallback(response) {
//											if (response.status === 200) {
//												console.log("response",response)
//													if (response.data.list.entries.length > 0) {
//														var listOfItems = response.data.list.entries;
//														
//														
//														console.log("listOfItems ",listOfItems);
//														console.log("listOfItems",listOfItems[0]);
//														
//														
//														
//														//console.log("response.length",listOfItems);
//														/*var segregatedByMime = segregateDataByMimeType(listOfItems);
//														setDetailsOfEachItem(segregatedByMime);
//														$scope.allItemsCount = response.data.items.length;*/
//												} else {
//													console.log('0 items in repository');
//												}
//											} else {
//												console.log('response other than 200 status code',response.status);
//											}
//											$scope.allItemsDetails = LatestCreatedService.getPropertiesOf(response);
//											console.log("allItemsDetails ",$scope.allItemsDetails);
//											
//											
//											
//										}, function errorCallback(response) {
//											console.log('error');
//											$state.go('login');
//										});
//
//					}
					//MostRead End
					
					
					/*$scope.mostReadOnClick = function() {

						// alert("I am inside the SalesProductsOnclick");
						$state.go('mostRead', {
							term : 'mostReadOnClick'
						});
					}*/
					
					
					
					$scope.onMostViewedClick = function() {
												
						alert("IndexController controller onMostViewedClick"); 
						$("[data-dismiss=modal]").trigger({ type: "click" });
				
						
						//$window.open('http://localhost:9090/#/view?id=2ade8895-cc12-4473-bcc6-06fd8b51e6ee&fileName=kerberos%20Configuration.txt&author=SandyReddy', '_self');
						console.log("inside onMostViewedClick");
						
					}
					
					
				

					$scope.initApp = function() {
						alert("IndexController controller initApp1"); 
						initilizeFeedbackDropdown();
						alert("IndexController controller initApp2"); 
						getAllItems();
						alert("IndexController controller initApp3"); 

					};

					angular
							.element(document)
							.ready(
									function() {
										console
												.log("**********IndexController*******");
										alert("indexcontrollerready");
										if ($rootScope.authenticated) {
											alert("indexcontrollerready1 root authenticated if");
											sessionStorage.setItem(
													'redirectUrl', $location
															.absUrl());
											alert("indexcontrollerready1 showSessionExpired calling");
											$scope.showSessionExpired();
											alert("indexcontrollerready1 init app calling2");
											$scope.initApp();
										} else {
											ControllerService
													.checkIfAlreadyAuthenticated(function() {
														alert("indexcontrollerready1 root authenticated else");
														// $scope.selectedMenuItem
														// = 'Products';
														if ($rootScope.authenticated) {
															sessionStorage
																	.setItem(
																			'redirectUrl',
																			$location
																					.absUrl());
															$scope.initApp();

														} else {
															sessionStorage
																	.setItem(
																			'redirectUrl',
																			$location
																					.absUrl());
															alert("indexcontrollerready1 init app calling2");
															$scope.initApp();
															$state.go('login');
														}
													});
										}
									});

				});