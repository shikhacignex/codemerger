/* Services */
angular
		.module('angularApp.services', [])
		.value('version', '0.1')
		.service(
				'UtilService',
				function($location, $rootScope, $filter, $http, UserDataService) {

					alert("UtilService pageload");
					// host of the alfresco server
					// uat: dmuat.edelcap.com
					this.contextRoot = function(){
						return "http://edelbsgcorpuat1.edelcap.com:9090";
					};
					this.alfrescoContextRoot = function() {
						return "http://edelbsgcorpuat1.edelcap.com:8080"; /*For UAT*/
						//  return "http://10.250.0.206:80";  /*For Prod*/
						//return "http://10.250.18.171:8080"; /*For UAT*/
						//return "http://10.250.18.171:8080";  
						//return "http://10.172.1.193:8080";
						// return "http://10.172.1.193:9090";
					};

					
					this.changeLocation = function(url, params) {
						if (params) {
							$location.path(url).search(params);
						} else {
							$location.search('id', null);
							$location.search('fileName', null);
							$location.path(url);
						}
						if (!$rootScope.$$phase) {
							$rootScope.$apply();
						}
					};

					this.contextRoot = function() {
						var path = location.pathname;
						var tempStr = path.split('/');
						if (window.location.href.indexOf(":80") > -1) {
							return "/" + tempStr[1];
						} else {
							return "";
						}
					};

					this.doAjax = function(method, url, body, callback) {
						try {
							$http({
								method : method,
								url : url,
								data : body
							}).then(function successCallback(response) {
								callback(response);
							}, function errorCallback(response) {
								callback(response);
							});
						} catch (e) {
							console.log("doAjax: ", e);
						}
					};

					this.encodeText = function(text) {
						var encodedText = '';
						if (text != '' || text != null || text != undefined) {
							encodeText = btoa(btoa(text));
						} else {
							encodeText = btoa(text);
						}
						return encodeText;
					}

					this.decodeText = function(text) {
						var decodedText = '';
						if (text != '' || text != null || text != undefined) {
							encodeText = atob(atob(text));
						} else {
							encodeText = atob(text);
						}
						return encodeText;
					}

					this.showAlert = function(type, title, message, size,
							buttonColor) {
					};
				})
		.service('UserDataService', function() {
			this.userLogged = "test";
			this.userGroup = "RPA";
		})
		.service('ControllerService',
				function($location, $rootScope, $filter, $http, UtilService,
						UserDataService) {
			alert("UtilService ControllerService");
					this.initController = function(scope) {
						if ($rootScope.authenticated) {
							alert("UtilService ControllerService init caliing1");
							scope.init();
						} else {
							this.checkIfAlreadyAuthenticated(function(
									authenticated) {
								if (authenticated) {
									alert("UtilService ControllerService init caliing2");
									scope.init();
								} else {
									// UtilService.changeLocation('/login');
									$state.go('login');
								}
							});
						}
					};

					this.checkIfAlreadyAuthenticated = function(callback) {
						if (sessionStorage.getItem('token')) {
							$rootScope.authenticated = true;
							callback($rootScope.authenticated);
						} else {
							$rootScope.authenticated = false;
							callback($rootScope.authenticated);
						}
					}
				})

		.service('DataService',
				function($location, $rootScope, $filter, $http, UtilService,
						UserDataService) {
			alert("UtilService DataService");
					var savedData = {};

					this.setAllSearchedItems = function(item) {
						savedData = item;
					};

					this.getAllSearchedItems = function() {
						return savedData;
					};
				})

		.service('BroadcastService', function($rootScope) {
			alert("UtilService BroadcastService");
			this.message = '';
			this.broadcastItem = function(msg) {
				this.message = msg;
				$rootScope.$broadcast('handleBroadcast');
			};
			this.broadcast = function(event, msg) {
				this.message = msg;
				$rootScope.$broadcast(event);
			};
		})
		.service('CommonDataService',
				function($rootScope, UtilService, UserDataService, $http,
						$compile, $location, $window, $filter) {
			alert("UtilService CommonDataService");
					this.showAlertModal = function(title, text) {
					}
				})
				
				
		.service('LatestCreatedService',
				function($http, UtilService, siteId) {
			alert("UtilService LatestCreatedService");
					this.getPropertiesOf = function(docType) {
						var details = new Array();
						
						//for (var i = 0; i < docType.data.list.entries.length; i++) {
							var doc = docType.data.list.entries[0];
							doc = doc.entry;
							console.log("item", doc);
							console.log("item", doc.name);
							var createdDate = (new Date(doc.createdAt)).toDateString().split(" ");
							console.log("createdDate:",createdDate);
							var dayAndMonth = new Array();
							dayAndMonth.push({
										"day" : createdDate[2],
										"month" : createdDate[1],
										"year" : createdDate[3]
									});
							console.log("dayAndMonth",dayAndMonth);

							if (doc) {

								details.push({
											"displayName" : doc.name.slice(0,
													doc.name.lastIndexOf(".")),
											"name" : doc.name,
											"by" : doc.properties["cm:author"] ? doc.properties["cm:author"]
													: '',
											"description" : doc.properties["cm:description"] ? doc.properties["cm:description"]
													: '',
											/*"category" : doc.properties["edcc:Theme"] ? doc.properties["edcc:Theme"]
													: '',*/
											"subCategory" : doc.properties["etm:Product"] ? doc.properties["etm:Product"]
											: ''|| doc.properties["etm:Marketing"] ? doc.properties["etm:Marketing"]
											: ''|| doc.properties["etm:Actuarial"] ? doc.properties["etm:Actuarial"]
											: ''|| doc.properties["etm:Sales"] ? doc.properties["etm:Sales"]
											: ''|| doc.properties["etm:OperationsAndServices"] ? doc.properties["etm:OperationsAndServices"]
											: ''|| doc.properties["etm:Investments"] ? doc.properties["etm:Investments"]
											: ''|| doc.properties["etm:AdminAndFacilities"] ? doc.properties["etm:AdminAndFacilities"]
											: ''|| doc.properties["etm:RiskManagement"] ? doc.properties["etm:RiskManagement"]
											: ''|| doc.properties["etm:Finance"] ? doc.properties["etm:Finance"]
											: ''|| doc.properties["etm:HRPolicy"] ? doc.properties["etm:HRPolicy"]
											: ''|| doc.properties["etm:InformationTechnology"] ? doc.properties["etm:InformationTechnology"]
											: ''|| doc.properties["etm:LegalAndCompliance"] ? doc.properties["etm:LegalAndCompliance"]
											: '',
											/*"sbu" : doc.properties["edcc:sbu"] ? doc.properties["edcc:sbu"]
													: '',*/
											"createdOn" : dayAndMonth[0].day +" "+dayAndMonth[0].month+" "+dayAndMonth[0].year
													,
											"id" : doc.id
										});
							}
						//}//close of for
						console.log("detailsArray : ", details);
						return details;
					}

					this.createSearchTerm = function(term) {
						alert("UtilService createSearchTerm");
						var searchTerm
						searchTerm = '\"' + term
								/*+ '\" OR etl:ProductsAndMarketing:\"' + term*/
								/*+ '\" OR cm:name:\"' + term
								+ '\" OR cm:title:\"' + term
								+ '\" OR cm:description:\"' + term
								+ '\" OR cm:content:\"' + term*/

						var splitTerm = term.split(/\s+/);
						for (var j = 0; j < splitTerm.length; j++) {
							searchTerm = searchTerm + ' OR \"' + splitTerm[j]
									//+ '\" OR etl:ProductsAndMarketing:\"' + splitTerm[j]
									/*+ '\" OR cm:name:\"' + splitTerm[j]
									+ '\" OR cm:title:\"' + splitTerm[j]
									+ '\" OR cm:description:\"' + splitTerm[j]
									+ '\" OR cm:content:\"' + splitTerm[j]*/
									+ '\"';
						}
						return searchTerm;
					}

					//Shreyas
					this.getCmisPropertiesOf = function(data) {
						alert("UtilService getCmisPropertiesOf");
						var details = new Array();
						var subCat = "";
						var date = new Date(data.results[0].properties['cmis:creationDate'].value);
						
						//Checking category
						if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Marketing")!=-1){
							subCat="Marketing";
				    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Product")!=-1){
				    		subCat="Product";
				    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:LegalAndCompliance")!=-1){
				    		subCat="Legal & Compliance";
				    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:OperationsAndServices")!=-1){
				    		subCat="Operations & Services";
				    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Actuarial")!=-1){
				    		subCat="Actuarial";
				    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:AdminAndFacilities")!=-1){
				    		subCat="Admin & Facilities";
				    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Investments")!=-1){
				    		subCat="Investments";
				    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Finance")!=-1){
				    		subCat="Finance";
				    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:HRPolicy")!=-1){
				    		subCat="HR Policy";
				    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:RiskManagement")!=-1){
				    		subCat="Risk Management";
				    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:InformationTechnology")!=-1){
				    		subCat="Information Technology";
				    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Sales")!=-1){
				    		subCat="Sales";
				    	}
						
						details.push({
							"displayName" : data.results[0].properties['cmis:name'].value.slice(0, data.results[0].properties['cmis:name'].value.lastIndexOf(".")),
							"name" : data.results[0].properties['cmis:name'].value,
							"by" : data.results[0].properties['cmis:createdBy'].value ? data.results[0].properties['cmis:createdBy'].value
									: '',
							"description" : data.results[0].properties['cmis:description'].value ? data.results[0].properties['cmis:description'].value
									: '',
							/*"category" : doc.properties["edcc:Theme"] ? doc.properties["edcc:Theme"]
									: '',*/
							"subCategory" : subCat ,
							/*"sbu" : doc.properties["edcc:sbu"] ? doc.properties["edcc:sbu"]
									: '',*/
							"createdOn" : date.toLocaleDateString()
									,
							"id" : data.results[0].properties['cmis:objectId'].value.slice(0, data.results[0].properties['cmis:objectId'].value.lastIndexOf(";"))
						});
						return details; 
					}
					
					this.getFilteredDocuments = function(searchTerm,categoryFilter, callback) {
						alert("UtilService getFilteredDocuments");
						// generating the search term and passing this term in
						// the search API
						var term = '';

						if (searchTerm == '*') {
							term = '*';
						} else {
							term = this.createSearchTerm(searchTerm);
						}

						var method = 'post';
						var url = "http://edelbsgcorpuat1.edelcap.com:8080"+ "/alfresco/api/-default-/public/search/versions/1/search";
						var body = {
							"query" : {
								"query" : "SITE:'" + siteId + "' AND (" + term
										+ ")",
								"language" : "afts"
							},
							"paging" : {
								"maxItems" : 100,
								"skipCount" : 0
							},
							"include" : [ "properties" ],
							"filterQueries" : [
									{
										"query" : "TYPE:'cm:content'"
									},
									{
										"query" : "-cm:creator:system"
									},
									{
										"query" : "-TYPE:'fm:post'"
									},
									{
										"query" : "etm:Product:'"+ categoryFilter + "' ||"
										 +"etm:Marketing:'"+ categoryFilter + "' ||"
										 +"etm:Actuarial:'"+ categoryFilter + "' ||"
										 +"etm:Sales:'"+ categoryFilter + "' ||"
										 +"etm:OperationsAndServices:'"+ categoryFilter + "' ||"
										 +"etm:Investments:'"+ categoryFilter + "' ||"
										 +"etm:AdminAndFacilities:'"+ categoryFilter + "' ||"
										 +"etm:RiskManagement:'"+ categoryFilter + "' ||"
										 +"etm:Finance:'"+ categoryFilter + "' ||"
										 +"etm:HRPolicy:'"+ categoryFilter + "' ||"
										 +"etm:InformationTechnology:'"+ categoryFilter + "' ||"
										 +"etm:LegalAndCompliance:'"+ categoryFilter + "'"
									}
									
									/*,
									{
										"query" : "etl:Actuarial:'"
												+ categoryFilter + "'"
									}*/],
									
									"sort" : [ {
										"type" : "FIELD",
										/*"field" : "cm:mimeType",*/
										"field" : "cm:created",
										/*"field" : "cm:modified",*/
										/*"ascending" : "true"*/
										"ascending" : "false"
									} ],
									
							'defaults' : {
								'textAttributes' : [ 'cm:content', 'cm:name',
										'cm:description', 'cm:title' ],
								'defaultFTSOperator' : 'OR',
								'defaultFTSFieldOperator' : 'OR',
								'namespace' : 'cm',
								'defaultFieldName' : '\"/\"'
							}
						};

						var headers = {
							withCredentials : true 
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {
							if (response.status === 200) {
								var entries = response.data.list.entries;
								callback(entries);
							} else {
								callback("error");
							}
						}, function errorCallback(response) {
							console.log(response);
							callback("error");
						});
					}
				})
				
		.service('AlertService',
				function($location, $rootScope, $filter, $http, UtilService,
						UserDataService) {

					this.notificationAlert = function(title, message) {
						modal({
							type : 'alert', // Type of Modal Box (alert |
							// confirm | prompt | success |
							// warning | error | info |
							// inverted | primary)
							title : title, // Modal Title
							text : message, // Modal HTML Content
							size : 'normal', // Modal Size (normal | large |
							// small)
							buttons : [ {
								text : 'OK', // Button Text
								val : 'ok', // Button Value
								eKey : true, // Enter Keypress
								addClass : 'btn-red btn-rounded', // Button
								onClick : function(dialog) {
									return true;
								}
							}, ],
							center : false, // Center Modal Box?
							autoclose : false, // Auto Close Modal Box?
							callback : null,
							onShow : function(r) {
							}, // After show Modal function
							closeClick : true, // Close Modal on click near the
							// box
							closable : true, // If Modal is closable
							theme : 'xenon', // Modal Custom Theme (xenon |
							// atlant | reseted)
							animate : false, // Slide animation
							background : 'rgba(0,0,0,0.35)', // Background
							// Color, it can
							// be null
							zIndex : 1050, // z-index
							buttonText : {
								ok : 'OK',
								yes : 'OK',
								cancel : 'Cancel'
							},
							template : '<div class="modal-box"><div class="modal-inner"><div class="modal-title"><a class="modal-close-btn"></a></div><div class="modal-text"></div><div class="modal-buttons"></div></div></div>',
							_classes : {
								box : '.modal-box',
								boxInner : ".modal-inner",
								title : '.modal-title',
								content : '.modal-text',
								buttons : '.modal-buttons',
								closebtn : '.modal-close-btn'
							}
						});
					}

					this.confirmationAlert = function(title, message,
							uploadType, action, username, jsonToPost) {
						alert("UtilService confirmationAlert");
						var self = this;

						modal({
							type : 'confirm', // Type of Modal Box (alert |
							// confirm | prompt | success |
							// warning | error | info |
							// inverted | primary)
							title : title, // Modal Title
							text : message, // Modal HTML Content
							size : 'normal', // Modal Size (normal | large |
							// small)
							buttons : [ {
								text : 'OK', // Button Text
								val : 'ok', // Button Value
								eKey : true, // Enter Keypress
								addClass : 'btn-red btn-rounded', // Button
								// Classes
								// (btn-large
								// |
								// btn-small
								// |
								// btn-green
								// |
								// btn-light-green
								// |
								// btn-purple
								// |
								// btn-orange
								// |
								// btn-pink
								// |
								// btn-turquoise
								// |
								// btn-blue
								// |
								// btn-light-blue
								// |
								// btn-light-red
								// | btn-red
								// |
								// btn-yellow
								// |
								// btn-white
								// |
								// btn-black
								// |
								// btn-rounded
								// |
								// btn-circle
								// |
								// btn-square
								// |
								// btn-disabled)
								onClick : function(dialog) {
									return true;
								}
							}, ],
							center : false, // Center Modal Box?
							autoclose : false, // Auto Close Modal Box?
							callback : function(confirmationAction) {
								// if (confirmationAction == true) {
								// var actionUrl = null;
								// switch (action) {
								// case "save": {
								// actionUrl = "api/admin/save-records/"
								// + uploadType + "/" + username;
								// break;
								// }
								// case "overwrite": {
								// actionUrl = "api/admin/save-records/"
								// + uploadType + "/" + username;
								// break;
								// }
								// case "deleteAll": {
								// actionUrl = "api/admin/delete-all/"
								// + uploadType + "/" + username;
								// break;
								// }
								// case "undoDelete": {
								// actionUrl = "api/admin/undo-delete/"
								// + uploadType + "/" + username;
								// break;
								// }
								// case "update": {
								// actionUrl = "api/admin/update/"
								// + uploadType + "/" + username;
								// break;
								// }
								// default:
								// break;
								// }
								//
								// if (actionUrl != null
								// && actionUrl != undefined) {
								// if (jsonToPost == null) {
								// $http
								// .get(
								// UtilService
								// .contextRoot()
								// + actionUrl)
								// .success(
								// function(data) {
								// console
								// .log(
								// "Action: "
								// + action
								// + " Upload Type: "
								// + uploadType,
								// data);
								// self
								// .notificationAlert(
								// "Alert",
								// data[0]);
								// })
								// .error(
								// (function(data) {
								// alert("Error while "
								// + action
								// + " operation");
								// }));
								// } else {
								// $http
								// .post(
								// UtilService
								// .contextRoot()
								// + actionUrl,
								// jsonToPost)
								// .success(
								// function(data) {
								// console
								// .log(
								// "Action: "
								// + action
								// + " Upload Type: "
								// + uploadType,
								// data);
								// self
								// .notificationAlert(
								// "Alert",
								// data[0]);
								// })
								// .error(
								// (function(data) {
								// alert("Error while "
								// + action
								// + " operation");
								// }));
								// }
								// }
								// }
								// return true;
							},
							onShow : function(r) {
							}, // After show Modal function
							closeClick : true, // Close Modal on click near the
							// box
							closable : true, // If Modal is closable
							theme : 'xenon', // Modal Custom Theme (xenon |
							// atlant | reseted)
							animate : false, // Slide animation
							background : 'rgba(0,0,0,0.35)', // Background
							// Color, it can
							// be null
							zIndex : 1050, // z-index
							buttonText : {
								ok : 'OK',
								yes : 'OK',
								cancel : 'Cancel'
							},
							template : '<div class="modal-box"><div class="modal-inner"><div class="modal-title"><a class="modal-close-btn"></a></div><div class="modal-text"></div><div class="modal-buttons"></div></div></div>',
							_classes : {
								box : '.modal-box',
								boxInner : ".modal-inner",
								title : '.modal-title',
								content : '.modal-text',
								buttons : '.modal-buttons',
								closebtn : '.modal-close-btn'
							}
						});

					}

					this.kendoNotificationAlert = function(bodyContent) {
						alert("UtilService kendoNotificationAlert");
						var window = $("<div id='firstWindow'></div>")
								.appendTo(document.body).kendoWindow({
									width : "25%",
									height : "10%",
									title : "Alert",
									modal : true,
									visible : false,
								});
						window
								.data("kendoWindow")
								.content(
										bodyContent
												+ "<br><a id='closeButton' class='k-button' style='position: absolute; bottom : 5%; right: 3%' onclick='A(firstWindow);'>OK</a><script type='text/javascript'>function A(id) {$('#closeButton').closest('.k-window-content').data('kendoWindow').close();$('#firstWindow').remove();}</script>")
								.center().open();
					}
				})
		/*.service(
				'UploadService',
				function($location, $rootScope, $filter, $http, $q, siteId,
						UtilService) {

					this.uploadFileToUrl = function(file, alf_ticket,contentAuthor, subTheme) {
						// FormData, object of key/value pair for form fields
						// and values
						var fileFormData = new FormData();
						fileFormData.append('file', file);
						// fileFormData.append('filename', 'TestFile');
						// fileFormData.append('contentAuthor', contentAuthor);
						// fileFormData.append('uploadDirectoryPath',
						// uploadDirectoryPath);
						// fileFormData.append('uploadDocumentPath',
						// uploadDocumentPath);

						// var siteid='bsg';

						// var
						// uploadUrlRedirect="http://10.172.1.193:8080/alfresco/service/api/upload/?alf_ticket="+
						// $scope.token

						// window.location.replace(uploadUrl+"?uploadDocumentPath="+fileFormData);
						// window.location.replace(uploadUrl+"?uploadDocumentPath="+fileFormData);

						var deffered = $q.defer();

						
						 * $http.post(uploadUrl, fileFormData, {
						 * transformRequest : angular.identity, headers : {
						 * 'Content-Type' : undefined }
						 * 
						 * }).success(function(response) {
						 * deffered.resolve(response);
						 * 
						 * }).error(function(response) {
						 

						// -------------------------------ServiceCall-------------------------------------------------------------
						$http(
								{
									method : 'POST',
									// url:
									// 'http://10.172.1.193:8080/alfresco/api/-default-/public/alfresco/versions/1/nodes/-my-/children',
									url : 'http://10.172.1.193:8080/alfresco/api/-default-/public/alfresco/versions/1/nodes/-root-/children',
									// url:
									// 'http://10.172.1.193:8080/alfresco/service/',
									// relativePath:'/sites/BSG/documentLibrary/Technical';
									headers : {
										// 'Content-Type':
										// 'multipart/form-data',
										'Content-Type' : undefined,
										'authorization' : "Basic "
												+ btoa(alf_ticket)
									},

									data : {
										// alf_ticket:alf_ticket,
										// properties: {
										// cm:author :'contentAuthor'
										// },
										filedata : file,
										// siteId: 'bsg',
										// containerId: 'documentLibrary',
										// uploaddirectory :
										// '/sites/BSG/documentLibrary/Technical',
										overwrite : 'false',
										nodeType : 'cm:content',
										relativePath : 'Sites/BSG/documentLibrary/Technical',
										autorename : 'true',
										'cm:author' : contentAuthor,
										// edcc:SubTheme : 'Tools and
										// Techniques'
										'edcc:SubTheme' : subTheme

									},
									transformRequest : function(data,
											headersGetter) {
										var formData = new FormData();
										angular.forEach(data, function(value,
												key) {
											formData.append(key, value);
											// formData.append('cm:author',
											// contentAuthor);
											// formData.append('edcc:SubTheme',
											// subCategory);
											console.log('key', value);
											console.log('value', value);
										});

										console.log("formData++++++++++",
												formData);
										var headers = headersGetter();
										delete headers['Content-Type'];

										return formData;
									}
								}).success(function(data) {

						}).error(function(data, status) {
							// ---------------------------------------------------------------------------------------------

							deffered.reject(response);
						});

						return deffered.promise;
					}
				});*/
				
		

