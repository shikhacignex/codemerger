'use strict';

var ViewController = angularApp.controller('ViewController',
				function ViewController($scope, $rootScope, $http, $state,
						$location, $routeParams, $stateParams, siteId,
						UtilService, AlertService, ControllerService,
						DataService, ViewService) {

					$scope.alfrescoContext = UtilService.alfrescoContextRoot();
					$scope.token = sessionStorage.getItem('token');
					
					$scope.loadIndexDocument = 4;

					// function to increase visible items
					$scope.ViewMore = function(item) {
						// don't increment if at the end of the list
						if (item === 'document') {
							if ($scope.loadIndexDocument < $scope.documentCount) {
								$scope.loadIndexDocument += 4;
								if ($scope.loadIndexDocument >= $scope.moreBestPractices.length) {
									//$("#docViewButton").addClass("disable-view-more-button");
									$("#viewAllId").hide();
								}
							}
						}

					};
					
					//Shreyas
					$scope.deleteComment = function(event) {
						var nodeId = $stateParams.id;
						var commentId = event.target.id;

						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
								+ nodeId + "/comments/" + commentId;
						var body = {};

						$.ajax({

						    url : url,
						    type : 'DELETE',
						    xhrFields: {
						        'withCredentials': true //Tell browser to provide credentials
						    },
						    data: body,
						    crossDomain: true,
						    success : function(data) {			
						    	 
						    	var comments = $scope.allComments;
								for (var i = 0; i < comments.length; i++) {
									var item = comments[i];
									if (item.id === commentId) {
										$scope.allComments.splice(i, 1);
										break;
									}
								}
								if ($scope.allComments.length > 0) {
									$scope.noComments = false;
								} else {
									$scope.noComments = true;
								}
								
						    },
						    error : function(request,error)
						    {
						    	console.log('ERROR DELETING COMMENT');
						    }
						  });
					}


//					$scope.deleteComment = function(event) {
//						var nodeId = $stateParams.id;
//						var commentId = event.target.id;
//
//						var method = 'delete';
//						var url = UtilService.alfrescoContextRoot()
//								+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
//								+ nodeId + "/comments/" + commentId;
//						var body = {};
//
//						var headers = {
//							authorization : "Basic "
//									+ btoa(sessionStorage.getItem('token'))
//						}
//
//						$http({
//							method : method,
//							url : url,
//							headers : headers,
//							data : body
//						}).then(function successCallback(response) {
//							/*console.log(response);*/
//							if (response.status === 204) {
//								//console.log('comment deleted: ', response);
//
//								var comments = $scope.allComments;
//								for (var i = 0; i < comments.length; i++) {
//									var item = comments[i];
//									if (item.id === commentId) {
//										$scope.allComments.splice(i, 1);
//										break;
//									}
//								}
//								if ($scope.allComments.length > 0) {
//									$scope.noComments = false;
//								} else {
//									$scope.noComments = true;
//								}
//							} else {
//								/*console.log('status != 200');*/
//							}
//						}, function errorCallback(response) {
//							/*console.log('error');*/
//						});
//					}

					/*var writeComment = function(id, content, callback) {
						if (content) {

							var method = 'post';
							var url = UtilService.alfrescoContextRoot()
									+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
									+ id
									+ "/comments?fields=id,content,canDelete,createdBy,createdAt";
							var body = {
								"content" : content
							};

							var headers = {
								authorization : "Basic "
										+ btoa(sessionStorage.getItem('token'))
							}

							$http({
								method : method,
								url : url,
								headers : headers,
								data : body
							})
									.then(
											function successCallback(response) {
												console.log(response);
												if (response.status === 201) {
													var entry = response.data.entry;
													$scope.allComments.splice(0,0,
																	{
																		"id" : entry.id,
																		"comment" : entry.content,
																		"canDelete" : entry.canDelete,
																		"createdBy" : entry.createdBy.firstName,
																				+ " "
																				+ entry.createdBy.lastName
																		"createdAt" : entry.createdAt
																	});
													$scope.noComments = false;
												} else {
													console
															.log('status != 200');
												}
												callback(true);
											},
											function errorCallback(response) {
												console.log('error');
												callback(true);
											});
						}
						$scope.commentText = '';
					}
*/					
					$scope.commId="";
	var getAllComments = function(id) {
						
						$scope.commId=id;
						
						$scope.allComments = [];
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
								+ id
								+ "/comments?fields=id,content,canDelete,createdBy,createdAt";
						var body = {};

						$.ajax({

						    url : url,
						    type : 'GET',
						    xhrFields: {
						        'withCredentials': true //Tell browser to provide credentials
						    },
						    data: body,
						    crossDomain: true,
						    success : function(data) {			
						    	 
								//alert(data);
								var comments = new Array();
								var entries = data.list.entries;
								if (entries.length > 0) {
									for (var i = 0; i < entries.length; i++) {
										var entry = entries[i].entry;
										
														var dateinlocal=new Date(entry.createdAt);
													
															var fragments=dateinlocal.toString().split(" ");
															var twelveHourDate=fragments[4];
															var twelve=ViewService.convertTime24to12(twelveHourDate);
													
														var createdDate = (new Date(
																entry.createdAt))
																.toDateString()
																.split(" ");
														
														var dayAndMonth = new Array();
														dayAndMonth
																.push({
																	"day" : createdDate[2],
																	"month" : createdDate[1],
																	"year" : createdDate[3]
																});
														
														comments.push({
																	"id" : entry.id,
																	"comment" : entry.content,
																	"canDelete" : entry.canDelete,
																	"createdBy" : entry.createdBy.firstName
																			+ " "
																			+ entry.createdBy.lastName,
																	"createdAt" : dayAndMonth[0].day +" "+dayAndMonth[0].month+" "+dayAndMonth[0].year+" "+twelve
										
									});
									}
									$scope.allComments = comments;
									$scope.$apply();
									$scope.noComments = false;
								} else {
									$scope.noComments = true;
								}
								
						    },
						    error : function(request,error)
						    {
						    	console.log('error');
						    }
						  });
					}
//					var getAllComments = function(id) {
//						
//						$scope.commId=id;
//						
//						$scope.allComments = [];
//						var method = 'get';
//						var url = UtilService.alfrescoContextRoot()
//								+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
//								+ id
//								+ "/comments?fields=id,content,canDelete,createdBy,createdAt";
//						var body = {};
//
//						var headers = {
//							authorization : "Basic "
//									+ btoa(sessionStorage.getItem('token'))
//						}
//
//						$http({
//							method : method,
//							url : url,
//							headers : headers,
//							data : body
//						})
//								.then(
//										function successCallback(response) {
//											if (response.status === 200) {
//												/*console.log('all comments: ',response.data.list.entries);*/
//
//												var comments = new Array();
//												var entries = response.data.list.entries;
//												if (entries.length > 0) {
//													for (var i = 0; i < entries.length; i++) {
//														var entry = entries[i].entry;
//														
//														
//														/*console.log("entry.createdAt",entry.createdAt);*/
//														
//														/*	modify hear+++++++++++++++ post comment	*/		
//																		
//																		var dateinlocal=new Date(entry.createdAt);
//																		
//																		/*console.log("++++++++++++++++++++++++dateinlocal ",dateinlocal);*/
//																		
//																		
//														//Date formate conversion start++++++++++++++++++++++++++++++++++++
//																		
//																	
//																			var fragments=dateinlocal.toString().split(" ");
//																			var twelveHourDate=fragments[4];
//
//																			var twelve=ViewService.convertTime24to12(twelveHourDate);
//																			/*console.log("twelve",twelve);*/		
//																		
//																		
//														//Date formate conversion end++++++++++++++++++++++++++++++++++++				
//																		
//																	
//																		var createdDate = (new Date(
//																				entry.createdAt))
//																				.toDateString()
//																				.split(" ");
//																		//console.log("++++++++++++++++++++++++createdDate after split ",createdDate);
//																		
//																		
//																		var dayAndMonth = new Array();
//																		dayAndMonth
//																				.push({
//																					"day" : createdDate[2],
//																					"month" : createdDate[1],
//																					"year" : createdDate[3]
//																				});
//																		
//																		
//																		
//																		/*console.log("dayAndMonth ",dayAndMonth);*/
//																				
//																		
//																		comments.push({
//																					"id" : entry.id,
//																					"comment" : entry.content,
//																					"canDelete" : entry.canDelete,
//																					"createdBy" : entry.createdBy.firstName
//																							+ " "
//																							+ entry.createdBy.lastName,
//																					//"createdAt" : entry.createdAt
//																					"createdAt" : dayAndMonth[0].day +" "+dayAndMonth[0].month+" "+dayAndMonth[0].year+" "+twelve
//														
//														
//														/*comments.push({
//																	"id" : entry.id,
//																	"comment" : entry.content,
//																	"canDelete" : entry.canDelete,
//																	"createdBy" : entry.createdBy.firstName,
//																			+ " "
//																			+ entry.createdBy.lastName
//																	"createdAt" : entry.createdAt
//																});*/
//													});
//													}
//													$scope.allComments = comments;
//													$scope.noComments = false;
//												} else {
//													/*console.log("No comments found");*/
//													// comments
//													// .push({
//													// "comment" : "(No
//													// comments)"
//													// });
//													// $scope.allComments =
//													// comments;
//													$scope.noComments = true;
//												}
//
//											} else {
//												/*console.log('status != 200');*/
//											}
//										}, function errorCallback(response) {
//											/*console.log('error');*/
//										});
//					}
					
					var commentVar;

					$scope.onCommentClick = function() {
						var id = $scope.id;
						var commentText = $scope.commentText.trim();

					if (commentText != null || commentText != undefined	|| commentText != '') {
						ViewService.comment(id,commentText,	function(entry) {
												// setting the new comment in
												// scope's all comment list
										var createdDate = (new Date(entry.createdAt))
										.toDateString()
										.split(" ");
												$scope.allComments.splice(0,0,
																{
																	"id" : entry.id,
																	"comment" : entry.content,
																	"canDelete" : entry.canDelete,
																	"createdBy" : entry.createdBy.firstName+ " " + entry.createdBy.lastName,
																	"createdAt" : entry.createdAt
																			/*+ " "
																			+ entry.createdBy.lastName*/
																});

												if ($scope.allComments.length > 0) {
													$scope.noComments = false;
												} else {
													$scope.noComments = true;
												}
											});
						}
						// setting the scope text to null on frontend
						$scope.commentText = '';
						commentVar = setTimeout(commentFunc, 1000);
					}
					
					function commentFunc() {
						getAllComments($scope.commId);
					}
					
					
					var generateReport =function(){
						
						var url = UtilService.alfrescoContextRoot()
						+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/?id="+$scope.IdCopy;
						console.log("insied the gerreports");
						
					}//close of generateReport
					
					
					
					

					var deleteLike = function(id) {
						$scope.likeStatus = !($scope.likeStatus);
						$scope.totalLikes = $scope.totalLikes - 1;

						var method = 'delete';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
								+ id + "/ratings/likes";
						var body = {};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {
							$scope.likeStatus = false;
							if (response.status === 200) {
								/*console.log('status 200');*/
							} else {
								/*console.log('status != 200');*/
							}
						}, function errorCallback(response) {
							/*console.log('error');*/
						});

					}

					var postLike = function(id) {
						$scope.likeStatus = !($scope.likeStatus);
						$scope.totalLikes = $scope.totalLikes + 1;
						var myRating = $scope.likeStatus;

						var method = 'post';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
								+ id + "/ratings";
						var body = {
							"id" : "likes",
							"myRating" : true
						};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {
							$scope.likeStatus = true;
							if (response.status === 200) {
								/*console.log(response);*/

							} else {
								/*console.log(response);*/
							}
						}, function errorCallback(response) {
							console.log('error');
						});
					}

					var getAllLikes = function(id) {
						var method = 'get';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
								+ id + "/ratings/likes";
						var body = {};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						})
								.then(
										function successCallback(response) {
											if (response.status === 200) {
												$scope.totalLikes = response.data.entry.aggregate.numberOfRatings;
												var status = response.data.entry.myRating;
												if (!status) {
													status = false;
												}
												$scope.likeStatus = status;
											} else {
												console.log('error != 200');
											}
										}, function errorCallback(response) {
											console.log('error');
										});
					}

					$scope.onLikeClick = function() {
						var id = $scope.id;
						if ($scope.likeStatus) {
							deleteLike(id);
						} else {
							postLike(id);
						}

					}
				
					var generateMoreBestPractices = function(maxItems,
							fileName, moreBestPractices) {
						/*var productsAndMarketingFilter = $stateParams.productsAndMarketing;
						console.log("productsAndMarketingFilter", productsAndMarketingFilter);*/
						
						var categoryFilter = $stateParams.category;
						/*console.log("categoryFilter", categoryFilter);*/
											
						var generatedBestPractices = new Array();
						var searchTerm = "SITE:'" + siteId + "' AND (*)"; // \"corporate-controller-bpri\"
						var method = 'post';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/search/versions/1/search";

						var body = {
							"query" : {
								"query" : searchTerm,
								"language" : "afts"
							},
							"paging" : {
								"maxItems" : maxItems,
								"skipCount" : 0
							},
							"include" : [ "properties" ],
							"filterQueries" : [
									{
										"query" : "TYPE:'cm:content'"
									},
									{
										"query" : "-cm:creator:system"
									},
									{
										"query" : "-TYPE:'fm:post'"
									},
									{
										"query" : "etm:Product:'"+ categoryFilter + "' ||"
										 +"etm:Marketing:'"+ categoryFilter + "' ||"
										 +"etm:Actuarial:'"+ categoryFilter + "' ||"
										 +"etm:Sales:'"+ categoryFilter + "' ||"
										 +"etm:OperationsAndServices:'"+ categoryFilter + "' ||"
										 +"etm:Investments:'"+ categoryFilter + "' ||"
										 +"etm:AdminAndFacilities:'"+ categoryFilter + "' ||"
										 +"etm:RiskManagement:'"+ categoryFilter + "' ||"
										 +"etm:Finance:'"+ categoryFilter + "' ||"
										 +"etm:HRPolicy:'"+ categoryFilter + "' ||"
										 +"etm:InformationTechnology:'"+ categoryFilter + "' ||"
										 +"etm:LegalAndCompliance:'"+ categoryFilter + "'"
									} ]
						}
						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,

							url : url,
							headers : headers,
							data : body
						})
								.then(
										function successCallback(response) {
											/*console.log("Generate more best practices: ",response);*/
											var entries = response.data.list.entries;
											for (var i = 0; i < entries.length; i++) {
												var entry = entries[i].entry;
												var name = entry.name;
												var id = entry.id;
												generatedBestPractices
														.push({
															"id" : id,
															"name" : name,
															"by" : entry.properties["cm:author"] ? entry.properties["cm:author"]
																	: '',
															/*"category" : entry.properties["edcc:Theme"] ? entry.properties["edcc:Theme"]
																	: '',*/
															/*"subCategory" : entry.properties["etl:ProductsAndMarketing"] ? entry.properties["etl:ProductsAndMarketing"]
																	: '',*/
														"subCategory" : entry.properties["etm:Product"] ? entry.properties["etm:Product"]
															: '' || entry.properties["etm:Marketing"] ? entry.properties["etm:Marketing"]
															: '' || entry.properties["etm:Actuarial"] ? entry.properties["etm:Actuarial"]
															: '' || entry.properties["etm:Sales"] ? entry.properties["etm:Sales"]
															: '' || entry.properties["etm:OperationsAndServices"] ? entry.properties["etm:OperationsAndServices"]
															: '' || entry.properties["etm:Investments"] ? entry.properties["etm:Investments"]
															: '' || entry.properties["etm:AdminAndFacilities"] ? entry.properties["etm:AdminAndFacilities"]
															: '' || entry.properties["etm:RiskManagement"] ? entry.properties["etm:RiskManagement"]
															: '' || entry.properties["etm:Finance"] ? entry.properties["etm:Finance"]
															: '' || entry.properties["etm:HRPolicy"] ? entry.properties["etm:HRPolicy"]
															: '' || entry.properties["etm:InformationTechnology"] ? entry.properties["etm:InformationTechnology"]
															: '' || entry.properties["etm:LegalAndCompliance"] ? entry.properties["etm:LegalAndCompliance"]
															: '',
															/*"sbu" : entry.properties["edcc:sbu"] ? entry.properties["edcc:sbu"]
																	: ''*/
														});
											}

											// $scope.generatedBestPractices =
											// generatedBestPractices;

											if (maxItems != 5) {
												for (var i = 0; i < generatedBestPractices.length; i++) {
													moreBestPractices.push(generatedBestPractices[i]);
												}
												$scope.moreBestPractices = moreBestPractices;
											} else {
												$scope.moreBestPractices = generatedBestPractices;
											}

										}, function errorCallback(response) {
											/*console.log('error');*/
										});
					}

	//				var findTopFiveDocuments = function(id, fileName,
//							searchTerm) {
//
//						searchTerm = "SITE:'" + siteId + "' AND (" // \"corporate-controller-bpri\"
//								+ searchTerm + ")";
//
//						if (id != null) {
//							var method = 'post';
//							var url = UtilService.alfrescoContextRoot()
//									+ "/alfresco/api/-default-/public/search/versions/1/search";
//							var body = {
//								"query" : {
//									"query" : searchTerm,
//									"language" : "afts"
//								},
//								"paging" : {
//									"maxItems" : 5,
//									"skipCount" : 0
//								},
//								"include" : [ "properties" ],
//								/* "path" */
//								/* "aspectNames" */
//								"filterQueries" : [ {
//									"query" : "TYPE:'cm:content'"
//								}, {
//									"query" : "-cm:creator:system"
//								}, {
//									"query" : "-TYPE:'fm:post'"
//								},
//								// excluding the file which is on
//								// view
//								{
//									"query" : "-cm:name:'" + fileName + "'"
//								// "query" : "-edcc:SubTheme:'" + 'CASESTUDIES
//								// AND Tools and Techniques' + "'"
//
//								}
//								// ,
//								// {
//								// "query" :
//								// "ANCESTOR:'workspace://SpacesStore/9553fe6f-0c15-4996-928c-dc919b30ab13'"
//								// }
//								],
//								/* "query" : "cm:creator:tanmaysalve" */
//								"sort" : [ {
//									"type" : "FIELD",
//									//"field" : "cm:mimeType",
//									"field" : "cm:created",
//									//"ascending" : "true"
//								} ],
//								'defaults' : {
//									'textAttributes' : [ 'cm:content' ],
//									'defaultFTSOperator' : 'OR',
//									'defaultFTSFieldOperator' : 'OR',
//									'namespace' : 'cm',
//									'defaultFieldName' : '\"/\"'
//								}
//							};
//
//							var headers = {
//								authorization : "Basic "
//										+ btoa(sessionStorage.getItem('token'))
//							}
//
//							$http({
//								method : method,
//								url : url,
//								headers : headers,
//								data : body
//							})
//									.then(
//											function successCallback(response) {
//												if (response.status === 200) {
//													var moreBestPractices = new Array();
//
//													if (response.data.list.entries.length > 0) {
//														var entries = response.data.list.entries;
//														/*console.log(
//																"entries: BP ",
//																entries);*/
//														for (var i = 0; i < entries.length; i++) {
//															var entry = entries[i].entry;
//															var name = entry.name;
//															var id = entry.id;
//
//															moreBestPractices
//																	.push({
//																		"id" : id,
//																		"name" : name,
//																		"by" : entry.properties["cm:author"] ? entry.properties["cm:author"]
//																				: '',
//																		/*"category" : entry.properties["edcc:Theme"] ? entry.properties["edcc:Theme"]
//																				: '',*/
//																		/*"subCategory" : entry.properties["etl:ProductsAndMarketing"] ? entry.properties["etl:ProductsAndMarketing"]
//																				: '',*/
//																		"subCategory" : entry.properties["etm:Product"] ? entry.properties["etm:Product"]
//																		: '' || entry.properties["etm:Marketing"] ? entry.properties["etm:Marketing"]
//																		: '' || entry.properties["etm:Actuarial"] ? entry.properties["etm:Actuarial"]
//																		: '' || entry.properties["etm:Sales"] ? entry.properties["etm:Sales"]
//																		: '' || entry.properties["etm:OperationsAndServices"] ? entry.properties["etm:OperationsAndServices"]
//																		: '' || entry.properties["etm:Investments"] ? entry.properties["etm:Investments"]
//																		: '' || entry.properties["etm:AdminAndFacilities"] ? entry.properties["etm:AdminAndFacilities"]
//																		: '' || entry.properties["etm:RiskManagement"] ? entry.properties["etm:RiskManagement"]
//																		: '' || entry.properties["etm:Finance"] ? entry.properties["etm:Finance"]
//																		: '' || entry.properties["etm:HRPolicy"] ? entry.properties["etm:HRPolicy"]
//																		: '' || entry.properties["etm:InformationTechnology"] ? entry.properties["etm:InformationTechnology"]
//																		: '' || entry.properties["etm:LegalAndCompliance"] ? entry.properties["etm:LegalAndCompliance"]
//																		: '',
//																		/*"sbu" : entry.properties["edcc:sbu"] ? entry.properties["edcc:sbu"]
//																				: ''*/
//																	});
//														}
//														/*
//														 * setting response on
//														 * UI
//														 */
//
//														if (response.data.list.entries.length < entries.length) {
//															$scope.lenth = entries.length;
//															/*console.log("lenth+++++++++++::value::",$scope.lenth);*/
//															var itemCount = response.data.list.entries.length;
//															generateMoreBestPractices($scope.lenth- itemCount,
//																	fileName,
//																	moreBestPractices);
//
//														} else {
//															$scope.moreBestPractices = moreBestPractices;
//														}
//													} else {
//														/*console.log('no items');*/
//														// getting '*' search &
//														// setting on UI
//														generateMoreBestPractices(
//																$scope.lenth,
//																fileName,
//																moreBestPractices);
//													}
//												} else {
//													/*console.log('code != 200',response);*/
//												}
//												
//												
//												/*console.log("moreBestPractices+++++++++++++++ ",moreBestPractices);*/
//												
//												if(moreBestPractices.length<=4){
//													$("#viewAllId").hide();
//												}
//												
//											},
//											function errorCallback(response) {
//												/*console.log('error');*/
//											});
//						}
//					}

					
//Shreyas
					
					var findTopFiveDocuments = function(id, fileName, searchTerm) {

						//alert($scope.subCategorycopy);
						//SITE:'etlife' AND ("Screenshot from 2018-10-24 14-23-34.png" OR (etm:AdminAndFacilities:"Courier Service Management" AND (cm:content:"Screenshot from 2018-10-24 14-23-34.png" OR cm:author:"admin")) OR ( etm:AdminAndFacilities:"Courier Service Management" AND NOT (etm:AdminAndFacilities:"Courier Service Management" AND (cm:content:"Screenshot from 2018-10-24 14-23-34.png" OR cm:author:"admin")))) Screenshot from 2018-10-24 14-23-34.png
						
						var payload = {'cmisaction': "query", 
							       'statement': searchTerm,
							       'maxItems':5,
							       'skipCount':0,};
				    
						$.ajax({

					    url : UtilService.alfrescoContextRoot() + '/alfresco/api/-default-/public/cmis/versions/1.1/browser',
					    type : 'POST',
					    xhrFields: {
					        'withCredentials': true //Tell browser to provide credentials
					    },
					    data: payload,
					    crossDomain: true,
					    success : function(data) {			
					    	var moreBestPractices = new Array();
					    	
							if (data.results.length > 0) {
								
								    for (var i = 0; i < data.results.length-1; i++) {
								    	
								    	if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Marketing")!=-1){
								    		$scope.subCategory="Marketing";
								    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Product")!=-1){
								    		$scope.subCategory="Product";
								    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:LegalAndCompliance")!=-1){
								    		$scope.subCategory="Legal & Compliance";
								    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:OperationsAndServices")!=-1){
								    		$scope.subCategory="Operations & Services";
								    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Actuarial")!=-1){
								    		$scope.subCategory="Actuarial";
								    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:AdminAndFacilities")!=-1){
								    		$scope.subCategory="Admin & Facilities";
								    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Investments")!=-1){
								    		$scope.subCategory="Investments";
								    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Finance")!=-1){
								    		$scope.subCategory="Finance";
								    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:HRPolicy")!=-1){
								    		$scope.subCategory="HR Policy";
								    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:RiskManagement")!=-1){
								    		$scope.subCategory="Risk Management";
								    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:InformationTechnology")!=-1){
								    		$scope.subCategory="Information Technology";
								    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Sales")!=-1){
								    		$scope.subCategory="Sales";
								    	}
								    	
								    	var date = new Date(data.results[i].properties['cmis:creationDate'].value);
								        $scope.by=data.results[i].properties['cmis:createdBy'].value;
										$scope.idIh=data.results[i].properties['cmis:objectId'].value.slice(0, data.results[0].properties['cmis:objectId'].value.lastIndexOf(";"));
										$scope.nameIh=data.results[i].properties['cmis:name'].value;
										$scope.m=date.toLocaleDateString();
										$scope.displayNameIH=data.results[i].properties['cmis:name'].value.slice(0, data.results[0].properties['cmis:name'].value.lastIndexOf("."));
										
										
										moreBestPractices
										.push({
											"id" : $scope.idIh,
											"name" : $scope.nameIh,
											"by" : $scope.by,
											"subCategory" : $scope.subCategory
										});
										
										$scope.moreBestPractices = moreBestPractices;
										$scope.$apply();
								    
								    }
								    
								   /* console.log(JSON.stringify(data));
								    
								    if (response.data.list.entries.length < entries.length) {
										$scope.lenth = entries.length;
										var itemCount = response.data.list.entries.length;
										generateMoreBestPractices($scope.lenth- itemCount,
												fileName,
												moreBestPractices);

									} else {
										$scope.moreBestPractices = moreBestPractices;
										$scope.$apply();
									}*/
								    
								    if($scope.moreBestPractices==undefined || $scope.moreBestPractices.length<=4){
										$("#viewAllId").hide();
									}
									
								} else {
									
									var payloadall = {'cmisaction': "query", 
										       'statement': "SELECT * FROM cmis:document WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND NOT(cmis:objectId = '"+id+"') ORDER BY cmis:creationDate DESC",
										       'maxItems':5,
										       'skipCount':0,};
									
									$.ajax({

									    url : UtilService.alfrescoContextRoot() + '/alfresco/api/-default-/public/cmis/versions/1.1/browser',
									    type : 'POST',
									    xhrFields: {
									        'withCredentials': true //Tell browser to provide credentials
									    },
									    data: payloadall,
									    crossDomain: true,
									    success : function(data) {
									    	
									    	if (data.results.length > 0) {
												
											    for (var i = 0; i < data.results.length-1; i++) {
											    	
											    	if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Marketing")!=-1){
											    		$scope.subCategory="Marketing";
											    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Product")!=-1){
											    		$scope.subCategory="Product";
											    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:LegalAndCompliance")!=-1){
											    		$scope.subCategory="Legal & Compliance";
											    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:OperationsAndServices")!=-1){
											    		$scope.subCategory="Operations & Services";
											    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Actuarial")!=-1){
											    		$scope.subCategory="Actuarial";
											    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:AdminAndFacilities")!=-1){
											    		$scope.subCategory="Admin & Facilities";
											    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Investments")!=-1){
											    		$scope.subCategory="Investments";
											    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Finance")!=-1){
											    		$scope.subCategory="Finance";
											    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:HRPolicy")!=-1){
											    		$scope.subCategory="HR Policy";
											    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:RiskManagement")!=-1){
											    		$scope.subCategory="Risk Management";
											    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:InformationTechnology")!=-1){
											    		$scope.subCategory="Information Technology";
											    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Sales")!=-1){
											    		$scope.subCategory="Sales";
											    	}
											    	
											    	var date = new Date(data.results[i].properties['cmis:creationDate'].value);
											        $scope.by=data.results[i].properties['cmis:createdBy'].value;
													$scope.idIh=data.results[i].properties['cmis:objectId'].value.slice(0, data.results[0].properties['cmis:objectId'].value.lastIndexOf(";"));
													$scope.nameIh=data.results[i].properties['cmis:name'].value;
													$scope.m=date.toLocaleDateString();
													$scope.displayNameIH=data.results[i].properties['cmis:name'].value.slice(0, data.results[0].properties['cmis:name'].value.lastIndexOf("."));
													
													
													moreBestPractices
													.push({
														"id" : $scope.idIh,
														"name" : $scope.nameIh,
														"by" : $scope.by,
														"subCategory" : $scope.subCategory
													});
													
													$scope.moreBestPractices = moreBestPractices;
													$scope.$apply();
											    
											    }
												
											}else{
												console.log('0 items in repository');
											}
									    	
									    	if($scope.moreBestPractices==undefined || $scope.moreBestPractices.length<=4){
												//$("#viewAllId").hide();
											}
									    	
									    }
									});
									
									
								}
								
							//$scope.documentDetails = LatestCreatedService.getCmisPropertiesOf(data);
							//console.log("HomeController ",$scope.documentDetails.length);
					    	
					    },
					    error : function(request,error)
					    {
					    	console.log('error');
							//$state.go('login');
					    }
					  });
						
						//alert($scope.moreBestPractices.length);
						
						
					}

					// $scope.subCategorycopy

//					var createSearchTerm = function(term, categoryFilter) {
//						/*console.log("$scope.subCategorycopy++++++",$scope.subCategorycopy);*/
//						var searchTerm
//						
//						if($scope.subCategorycopy == "Product"){
//						searchTerm = '\"' + term 				
//						
//						+'\" OR (etm:Product:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author 						 
//						 + '\")) OR ( etm:Product:\"'+ $scope.subCategorycopy
//						+'\" AND NOT (etm:Product:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author + "\")))"
//						
//						var splitTerm = term.split(/\s+/)
//						return searchTerm;
//					}else if($scope.subCategorycopy == "Marketing" ){
//						searchTerm = '\"' + term 				
//						
//						+'\" OR (etm:Marketing:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author 						 
//						 + '\")) OR ( etm:Marketing:\"'+ $scope.subCategorycopy
//						+'\" AND NOT (etm:Marketing:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author + "\")))"
//						
//						var splitTerm = term.split(/\s+/)
//						return searchTerm;
//					}else if($scope.subCategorycopy == "Reporting And Modelling" || $scope.subCategorycopy == "Valuation And Reinsurance"){
//						
//						searchTerm = '\"' + term 				
//						
//						+'\" OR (etm:Actuarial:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author 						 
//						 + '\")) OR ( etm:Actuarial:\"'+ $scope.subCategorycopy
//						+'\" AND NOT (etm:Actuarial:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author + "\")))"
//						
//						var splitTerm = term.split(/\s+/)
//						return searchTerm;
//					}else if($scope.subCategorycopy == "Organic Agency" || $scope.subCategorycopy == "Bancassurance" || $scope.subCategorycopy == "Direct Sales" || $scope.subCategorycopy == "CBM" || $scope.subCategorycopy == "Web Sales" || $scope.subCategorycopy == "Sales Strategy"){
//						searchTerm = '\"' + term 				
//						
//						+'\" OR (etm:Sales:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author 						 
//						 + '\")) OR ( etm:Sales:\"'+ $scope.subCategorycopy
//						+'\" AND NOT (etm:Sales:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author + "\")))"
//						
//						var splitTerm = term.split(/\s+/)
//						return searchTerm;
//						
//					}else if($scope.subCategorycopy == "Branch Services" || $scope.subCategorycopy == "Agent Onboarding" || $scope.subCategorycopy == "Commission" || $scope.subCategorycopy == "New Business" || $scope.subCategorycopy == "UnderWriting" || $scope.subCategorycopy == "Policy Servicing" || $scope.subCategorycopy == "Customer Services" || $scope.subCategorycopy == "Retention" || $scope.subCategorycopy == "Claims")
//					{
//						searchTerm = '\"' + term 				
//						
//						+'\" OR (etm:OperationsAndServices:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author 						 
//						 + '\")) OR ( etm:OperationsAndServices:\"'+ $scope.subCategorycopy
//						+'\" AND NOT (etm:OperationsAndServices:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author + "\")))"
//						
//						var splitTerm = term.split(/\s+/)
//						return searchTerm;	
//					}else if($scope.subCategorycopy == "Investments")
//					{
//						searchTerm = '\"' + term 				
//						
//						+'\" OR (etm:Investments:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author 						 
//						 + '\")) OR ( etm:Investments:\"'+ $scope.subCategorycopy
//						+'\" AND NOT (etm:Investments:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author + "\")))"
//						
//						var splitTerm = term.split(/\s+/)
//						return searchTerm;	
//					}else if($scope.subCategorycopy == "Vendor Management" || $scope.subCategorycopy == "Recovery Of Security Deposit" || $scope.subCategorycopy == "Courier Service Management" || $scope.subCategorycopy == "Budgeting And Expenditure" || $scope.subCategorycopy == "Record Management")
//					{
//						searchTerm = '\"' + term 								
//						+'\" OR (etm:AdminAndFacilities:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author 						 
//						 + '\")) OR ( etm:AdminAndFacilities:\"'+ $scope.subCategorycopy
//						+'\" AND NOT (etm:AdminAndFacilities:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author + "\")))"
//						
//						var splitTerm = term.split(/\s+/)
//						return searchTerm;	
//					}else if($scope.subCategorycopy == "Fraud Risk Management" || $scope.subCategorycopy == "Information Security Process" || $scope.subCategorycopy == "Exception Management" || $scope.subCategorycopy == "Cyber Crisis Management")
//					{
//						searchTerm = '\"' + term 								
//						+'\" OR (etm:RiskManagement:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author 						 
//						 + '\")) OR ( etm:RiskManagement:\"'+ $scope.subCategorycopy
//						+'\" AND NOT (etm:RiskManagement:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author + "\")))"
//						
//						var splitTerm = term.split(/\s+/)
//						return searchTerm;	
//					}else if($scope.subCategorycopy == "Taxation" || $scope.subCategorycopy == "Financial Closing Process" || $scope.subCategorycopy == "Cash Management Process" || $scope.subCategorycopy == "Finance Manual" || $scope.subCategorycopy == "Bank Reconciliation Process" || $scope.subCategorycopy == "Travel Management")
//					{
//						searchTerm = '\"' + term 								
//						+'\" OR (etm:Finance:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author 						 
//						 + '\")) OR ( etm:Finance:\"'+ $scope.subCategorycopy
//						+'\" AND NOT (etm:Finance:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author + "\")))"
//						
//						var splitTerm = term.split(/\s+/)
//						return searchTerm;	
//					}else if($scope.subCategorycopy == "Policies" || $scope.subCategorycopy == "Learning and Development" || $scope.subCategorycopy == "Forms" || $scope.subCategorycopy == "SOPs")
//					{
//						searchTerm = '\"' + term 								
//						+'\" OR (etm:HRPolicy:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author 						 
//						 + '\")) OR ( etm:HRPolicy:\"'+ $scope.subCategorycopy
//						+'\" AND NOT (etm:HRPolicy:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author + "\")))"
//						
//						var splitTerm = term.split(/\s+/)
//						return searchTerm;	
//					}else if($scope.subCategorycopy == "IT" || $scope.subCategorycopy == "Infra Management Process")
//					{
//						searchTerm = '\"' + term 								
//						+'\" OR (etm:InformationTechnology:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author 						 
//						 + '\")) OR ( etm:InformationTechnology:\"'+ $scope.subCategorycopy
//						+'\" AND NOT (etm:InformationTechnology:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author + "\")))"
//						
//						var splitTerm = term.split(/\s+/)
//						return searchTerm;	
//					}else if($scope.subCategorycopy == "Legal" || $scope.subCategorycopy == "Compliance")
//					{
//						searchTerm = '\"' + term 								
//						+'\" OR (etm:LegalAndCompliance:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author 						 
//						 + '\")) OR ( etm:LegalAndCompliance:\"'+ $scope.subCategorycopy
//						+'\" AND NOT (etm:LegalAndCompliance:\"'+ $scope.subCategorycopy+ '\" AND (cm:content:\"'+ term +'\" OR cm:author:\"'+ $scope.author + "\")))"
//						
//						var splitTerm = term.split(/\s+/)
//						return searchTerm;	
//					}
//						
//					}

					
					var createSearchTerm = function(term, categoryFilter, id) {
						//alert(term);
						var searchTerm="";
						
						if($scope.subCategorycopy == "Product"){
						
						searchTerm = "SELECT * FROM etm:Product WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND (etm:Product = \'"+categoryFilter+"\' OR cmis:createdBy = \'"+$scope.author+"\' OR (cmis:name like '%"+term+"%')) AND NOT(cmis:objectId = '"+id+"') ORDER BY cmis:creationDate DESC"
						
						return searchTerm;
					}else if($scope.subCategorycopy == "Marketing" ){
						
						searchTerm = "SELECT * FROM etm:Marketing WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND (etm:Marketing = \'"+categoryFilter+"\' OR cmis:createdBy = \'"+$scope.author+"\' OR (cmis:name like '%"+term+"%')) AND NOT(cmis:objectId = '"+id+"') ORDER BY cmis:creationDate DESC"
						
						return searchTerm;
					}else if($scope.subCategorycopy == "Reporting And Modelling" || $scope.subCategorycopy == "Valuation And Reinsurance"){
						
						searchTerm = "SELECT * FROM etm:Actuarial WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND (etm:Actuarial = \'"+categoryFilter+"\' OR cmis:createdBy = \'"+$scope.author+"\' OR (cmis:name like '%"+term+"%')) AND NOT(cmis:objectId = '"+id+"') ORDER BY cmis:creationDate DESC"
						
						return searchTerm;
					}else if($scope.subCategorycopy == "Organic Agency" || $scope.subCategorycopy == "Bancassurance" || $scope.subCategorycopy == "Direct Sales" || $scope.subCategorycopy == "CBM" || $scope.subCategorycopy == "Web Sales" || $scope.subCategorycopy == "Sales Strategy"){
						
						searchTerm = "SELECT * FROM etm:Sales WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND (etm:Sales = \'"+categoryFilter+"\' OR cmis:createdBy = \'"+$scope.author+"\' OR (cmis:name like '%"+term+"%')) AND NOT(cmis:objectId = '"+id+"') ORDER BY cmis:creationDate DESC"
						
						return searchTerm;
					}else if($scope.subCategorycopy == "Branch Services" || $scope.subCategorycopy == "Agent Onboarding" || $scope.subCategorycopy == "Commission" || $scope.subCategorycopy == "New Business" || $scope.subCategorycopy == "UnderWriting" || $scope.subCategorycopy == "Policy Servicing" || $scope.subCategorycopy == "Customer Services" || $scope.subCategorycopy == "Retention" || $scope.subCategorycopy == "Claims"){

						searchTerm = "SELECT * FROM etm:OperationsAndServices WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND (etm:OperationsAndServices = \'"+categoryFilter+"\' OR cmis:createdBy = \'"+$scope.author+"\' OR (cmis:name like '%"+term+"%')) AND NOT(cmis:objectId = '"+id+"') ORDER BY cmis:creationDate DESC"
						
						return searchTerm;
					}else if($scope.subCategorycopy == "Investments")					{

						searchTerm = "SELECT * FROM etm:Investments WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND (etm:Investments = \'"+categoryFilter+"\' OR cmis:createdBy = \'"+$scope.author+"\' OR (cmis:name like '%"+term+"%')) AND NOT(cmis:objectId = '"+id+"') ORDER BY cmis:creationDate DESC"
						
						return searchTerm;
					}else if($scope.subCategorycopy == "Vendor Management" || $scope.subCategorycopy == "Recovery Of Security Deposit" || $scope.subCategorycopy == "Courier Service Management" || $scope.subCategorycopy == "Budgeting And Expenditure" || $scope.subCategorycopy == "Record Management"){
						searchTerm = "SELECT * FROM etm:AdminAndFacilities WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND (etm:AdminAndFacilities = \'"+categoryFilter+"\' OR cmis:createdBy = \'"+$scope.author+"\' OR (cmis:name like '%"+term+"%')) AND NOT(cmis:objectId = '"+id+"') ORDER BY cmis:creationDate DESC"
						
						return searchTerm;	
					}else if($scope.subCategorycopy == "Fraud Risk Management" || $scope.subCategorycopy == "Information Security Process" || $scope.subCategorycopy == "Exception Management" || $scope.subCategorycopy == "Cyber Crisis Management"){
						searchTerm = "SELECT * FROM etm:RiskManagement WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND (etm:RiskManagement = \'"+categoryFilter+"\' OR cmis:createdBy = \'"+$scope.author+"\' OR (cmis:name like '%"+term+"%')) AND NOT(cmis:objectId = '"+id+"') ORDER BY cmis:creationDate DESC"
						
						return searchTerm;
					}else if($scope.subCategorycopy == "Taxation" || $scope.subCategorycopy == "Financial Closing Process" || $scope.subCategorycopy == "Cash Management Process" || $scope.subCategorycopy == "Finance Manual" || $scope.subCategorycopy == "Bank Reconciliation Process" || $scope.subCategorycopy == "Travel Management"){
						searchTerm = "SELECT * FROM etm:Finance WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND (etm:Finance = \'"+categoryFilter+"\' OR cmis:createdBy = \'"+$scope.author+"\' OR (cmis:name like '%"+term+"%')) AND NOT(cmis:objectId = '"+id+"') ORDER BY cmis:creationDate DESC"
						
						return searchTerm;	
					}else if($scope.subCategorycopy == "Policies" || $scope.subCategorycopy == "Learning and Development" || $scope.subCategorycopy == "Forms" || $scope.subCategorycopy == "SOPs"){
						searchTerm = "SELECT * FROM etm:HRPolicy WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND (etm:HRPolicy = \'"+categoryFilter+"\' OR cmis:createdBy = \'"+$scope.author+"\' OR (cmis:name like '%"+term+"%')) AND NOT(cmis:objectId = '"+id+"') ORDER BY cmis:creationDate DESC"
						
						return searchTerm;
					}else if($scope.subCategorycopy == "IT" || $scope.subCategorycopy == "Infra Management Process"){
						searchTerm = "SELECT * FROM etm:InformationTechnology WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND (etm:InformationTechnology = \'"+categoryFilter+"\' OR cmis:createdBy = \'"+$scope.author+"\' OR (cmis:name like '%"+term+"%')) AND NOT(cmis:objectId = '"+id+"') ORDER BY cmis:creationDate DESC"
						
						return searchTerm;
					}else if($scope.subCategorycopy == "Legal" || $scope.subCategorycopy == "Compliance"){
						searchTerm = "SELECT * FROM etm:LegalAndCompliance WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND (etm:LegalAndCompliance = \'"+categoryFilter+"\' OR cmis:createdBy = \'"+$scope.author+"\' OR (cmis:name like '%"+term+"%')) AND NOT(cmis:objectId = '"+id+"') ORDER BY cmis:creationDate DESC"
						
						return searchTerm;	
					}
						
					}
					
					
					var getMoreBestPractices = function(id, fileName) {
						var categoryFilter = $stateParams.category;
						/*console.log("categoryFilter in getMoreBestPractices", categoryFilter);*/
						var searchTerm = createSearchTerm(fileName,categoryFilter);
						
						/*console.log("searchTerm ", searchTerm);*/

						findTopFiveDocuments(id, fileName, searchTerm);
					}

					
					var previewDocument = function(id, fileName) {
						var fileExtension = fileName.slice((fileName
								.lastIndexOf(".") + 1), fileName.length);

						var viewContent = $('#viewContent');
						var htmlContent = '';
						var encodedFilePath = '';

						if (fileExtension != undefined || fileExtension != null) {

							if ((fileExtension.trim().toLowerCase() === 'pdf')) {
								encodedFilePath = encodeURIComponent(UtilService
										.alfrescoContextRoot()
										+ "/alfresco/service/api/node/workspace/SpacesStore/"
										+ id
										+ "/content/pdf?c=force&alf_ticket="
										+ $scope.token);

								htmlContent = "<iframe allowfullscreen webkitallowfullscreen mozallowfullscreen=true	class='banner banner2' src='js/lib/pdfjs/web/viewer.html?file="
										+ encodedFilePath + "'></iframe>";

							} else if (fileExtension.trim().toLowerCase() === 'mp4'
									|| fileExtension.trim().toLowerCase() === 'ogv'
									|| fileExtension.trim().toLowerCase() === 'webm') {
								encodedFilePath = (UtilService
										.alfrescoContextRoot()
										+ "/alfresco/service/api/node/workspace/SpacesStore/"
										+ id
										+ "/content/pdf?c=force&alf_ticket=" + $scope.token);

								htmlContent = "<video controls autoplay controlsList='nodownload' class='banner'> <source src='"
										+ encodedFilePath
										+ "' type='video/mp4'> </video>";
							} else {
								encodedFilePath = encodeURIComponent(UtilService
										.alfrescoContextRoot()
										+ "/alfresco/service/api/node/workspace/SpacesStore/"
										+ id
										+ "/content/thumbnails/pdf?c=force&alf_ticket="
										+ $scope.token + "#page=1");

								htmlContent = "<iframe allowfullscreen webkitallowfullscreen mozallowfullscreen=true class='banner banner2' src='js/lib/pdfjs/web/viewer.html?file="
										+ encodedFilePath + "'></iframe>";
							}

						} else {
							htmlContent = "<h2> CANNOT PREVIEW</h2> ";
						}

						viewContent.find('#content').html(htmlContent);
					}

					var setDetails = function(id, fileName, author,
							description, dayAndMonth) {
						$scope.view = new Array();
						$scope.id = id;
						$scope.view.name = fileName ? fileName : '';
						$scope.view.author = author ? author : '';
						//$scope.view.sbu = sbu ? sbu : '';
						$scope.view.description = description ? description
								: ''
						$scope.view.day = dayAndMonth[0].day ? dayAndMonth[0].day
								: '00';
						$scope.view.month = dayAndMonth[0].month ? dayAndMonth[0].month
								: 'YYY';
						$scope.view.year = dayAndMonth[0].year ? dayAndMonth[0].year
								: 'YYYY';
					}

//					var init = function() {
//						getAllItems();
//						var id = $stateParams.id;
//						$scope.IdCopy=$stateParams.id;
//						console.log("$scope.IdCopy+++++++++++++++++",$scope.IdCopy);
//						
//						var fileName = $stateParams.fileName;
//						var author = $stateParams.author;
//						$scope.author = $stateParams.author;
//
//						if (id === null || id === undefined || id === '') {
//							$state.go('homeEtlife');
//						} else {
//							var method = 'get';
//							var url = UtilService.alfrescoContextRoot()
//									+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
//									+ id;
//							var body = {};
//
//							var headers = {
//								authorization : "Basic "
//										+ btoa(sessionStorage.getItem('token'))
//							}
//
//							$http({
//								method : method,
//								url : url,
//								headers : headers,
//								data : body
//							})
//									.then(
//											function successCallback(response) {
//												$scope.likeStatus = true;
//												if (response.status === 200) {
//
//													var createdDate = (new Date(
//															response.data.entry.createdAt))
//															.toDateString()
//															.split(" ");
//													// var category =
//													// response.data.entry.properties["edcc:Theme"];
//													
//													
//													
//													//$scope.subCategorycopy = response.data.entry.properties["etl:ProductsAndMarketing"];
//										if(response.data.entry.properties["etm:Product"]){
//											var subCategory = response.data.entry.properties["etm:Product"];
//											$scope.subCategorycopy = response.data.entry.properties["etm:Product"];
//											}else if(response.data.entry.properties["etm:Marketing"]){
//												var subCategory = response.data.entry.properties["etm:Marketing"];
//												$scope.subCategorycopy = response.data.entry.properties["etm:Marketing"];
//											}else if(response.data.entry.properties["etm:Actuarial"]){
//											 var subCategory = response.data.entry.properties["etm:Actuarial"];
//											$scope.subCategorycopy = response.data.entry.properties["etm:Actuarial"];
//											}else if(response.data.entry.properties["etm:Sales"]){	
//											 var subCategory = response.data.entry.properties["etm:Sales"];
//											$scope.subCategorycopy = response.data.entry.properties["etm:Sales"];
//											} else if(response.data.entry.properties["etm:OperationsAndServices"]){
//												var subCategory = response.data.entry.properties["etm:OperationsAndServices"];
//												$scope.subCategorycopy = response.data.entry.properties["etm:OperationsAndServices"];
//											}else if(response.data.entry.properties["etm:Investments"]){
//												var subCategory = response.data.entry.properties["etm:Investments"];
//												$scope.subCategorycopy = response.data.entry.properties["etm:Investments"];
//											}else if(response.data.entry.properties["etm:AdminAndFacilities"]){
//												var subCategory = response.data.entry.properties["etm:AdminAndFacilities"];
//												$scope.subCategorycopy = response.data.entry.properties["etm:AdminAndFacilities"];
//											}else if(response.data.entry.properties["etm:RiskManagement"]){
//												var subCategory = response.data.entry.properties["etm:RiskManagement"];
//												$scope.subCategorycopy = response.data.entry.properties["etm:RiskManagement"];
//											}else if(response.data.entry.properties["etm:Finance"]){
//												var subCategory = response.data.entry.properties["etm:Finance"];
//												$scope.subCategorycopy = response.data.entry.properties["etm:Finance"];
//											}else if(response.data.entry.properties["etm:HRPolicy"]){
//												var subCategory = response.data.entry.properties["etm:HRPolicy"];
//												$scope.subCategorycopy = response.data.entry.properties["etm:HRPolicy"];
//											}else if(response.data.entry.properties["etm:InformationTechnology"]){
//												var subCategory = response.data.entry.properties["etm:InformationTechnology"];
//												$scope.subCategorycopy = response.data.entry.properties["etm:InformationTechnology"];
//											}else if(response.data.entry.properties["etm:LegalAndCompliance"]){
//												var subCategory = response.data.entry.properties["etm:LegalAndCompliance"];
//												$scope.subCategorycopy = response.data.entry.properties["etm:LegalAndCompliance"];
//											}
//
//													/*console.log("subCategory : value : ;",	subCategory)
//													console.log("$scope.subCategorycopy  Value : ",	$scope.subCategorycopy);;*/
//													//var sbu = response.data.entry.properties["edcc:sbu"];
//													var description = response.data.entry.properties["cm:description"];
//
//													var dayAndMonth = new Array();
//													dayAndMonth
//															.push({
//																"day" : createdDate[2],
//																"month" : createdDate[1],
//																"year" : createdDate[3]
//															});
//
//													setDetails(id, fileName,
//															$scope.author,
//															description,
//															dayAndMonth);
//
//													previewDocument(id,
//															fileName);
//
//													getMoreBestPractices(id,
//															fileName);
//
//													getAllLikes(id);
//													getAllComments(id);
//												} else {
//													/*console.log(response);*/
//												}
//											},
//											function errorCallback(response) {
//												/*console.log('error');*/
//												$state.go('login');
//											});
//						}
//					}
//					
					//Shreyas
					var init = function() {
						getAllItems();
						var id = $stateParams.id;
						var fileName = $stateParams.fileName;
						var author = $stateParams.author;
						$scope.author = $stateParams.author;

						if (id === null || id === undefined || id === '') {
							$state.go('homeEtlife');
						} else {
							$.ajax({

							    url : UtilService.alfrescoContextRoot()	+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/" + id,
							    type : 'GET',
							    xhrFields: {
							        'withCredentials': true //Tell browser to provide credentials
							    },
							    //data: payload,
							    //crossDomain: true,
							    success : function(response) {
							    	console.log(JSON.stringify(response));
							    	$scope.likeStatus = true;

									var createdDate = (new Date(response.entry.createdAt)).toDateString().split(" ");
										
									if(response.entry.properties["etm:Product"]){
										var subCategory = response.entry.properties["etm:Product"];
										$scope.subCategorycopy = response.entry.properties["etm:Product"];
									}else if(response.entry.properties["etm:Marketing"]){
										var subCategory = response.entry.properties["etm:Marketing"];
										$scope.subCategorycopy = response.entry.properties["etm:Marketing"];
									}else if(response.entry.properties["etm:Actuarial"]){
										var subCategory = response.entry.properties["etm:Actuarial"];
										$scope.subCategorycopy = response.entry.properties["etm:Actuarial"];
									}else if(response.entry.properties["etm:Sales"]){	
										var subCategory = response.entry.properties["etm:Sales"];
										$scope.subCategorycopy = response.entry.properties["etm:Sales"];
									} else if(response.entry.properties["etm:OperationsAndServices"]){
										var subCategory = response.entry.properties["etm:OperationsAndServices"];
										$scope.subCategorycopy = response.entry.properties["etm:OperationsAndServices"];
									}else if(response.entry.properties["etm:Investments"]){
										var subCategory = response.entry.properties["etm:Investments"];
										$scope.subCategorycopy = response.entry.properties["etm:Investments"];
									}else if(response.entry.properties["etm:AdminAndFacilities"]){
										var subCategory = response.entry.properties["etm:AdminAndFacilities"];
										$scope.subCategorycopy = response.entry.properties["etm:AdminAndFacilities"];
									}else if(response.entry.properties["etm:RiskManagement"]){
										var subCategory = response.entry.properties["etm:RiskManagement"];
										$scope.subCategorycopy = response.entry.properties["etm:RiskManagement"];
									}else if(response.entry.properties["etm:Finance"]){
										var subCategory = response.entry.properties["etm:Finance"];
										$scope.subCategorycopy = response.entry.properties["etm:Finance"];
									}else if(response.entry.properties["etm:HRPolicy"]){
										var subCategory = response.entry.properties["etm:HRPolicy"];
										$scope.subCategorycopy = response.entry.properties["etm:HRPolicy"];
									}else if(response.entry.properties["etm:InformationTechnology"]){
										var subCategory = response.entry.properties["etm:InformationTechnology"];
										$scope.subCategorycopy = response.entry.properties["etm:InformationTechnology"];
									}else if(response.entry.properties["etm:LegalAndCompliance"]){
										var subCategory = response.entry.properties["etm:LegalAndCompliance"];
										$scope.subCategorycopy = response.entry.properties["etm:LegalAndCompliance"];
									}

										var description = response.entry.properties["cm:description"];

										var dayAndMonth = new Array();
										dayAndMonth
												.push({
													"day" : createdDate[2],
													"month" : createdDate[1],
													"year" : createdDate[3]
												});

										setDetails(id, fileName,
												$scope.author,
												description,
												dayAndMonth);

										previewDocument(id,
												fileName);

										getMoreBestPractices(id,
												fileName);

										//getAllLikes(id);
										getAllComments(id);
									
							    },
							    error : function(request,error)
							    {
							    	console.log('error');
							    }
							  });
						}
					}
					
					//added by sandeep
					
					var getPropertiesOf = function(docType) {
						var details = new Array();
						for (var i = 0; i < docType.length; i++) {
							var doc = docType[i];
							if (doc.name != null || doc.properties != null
									|| doc.id != null || doc.name != undefined
									|| doc.properties != undefined
									|| doc.id != undefined || doc.name != ''
									|| doc.properties != '' || doc.id != '') {

								details.push({
											"displayName" : doc.name.slice(0,
													doc.name.lastIndexOf(".")),
											"name" : doc.name,
											"by" : doc.properties["cm:author"] ? doc.properties["cm:author"]
													: '',
											"description" : doc.properties["cm:description"] ? doc.properties["cm:description"]
													: '',
											/*"category" : doc.properties["edcc:Theme"] ? doc.properties["edcc:Theme"]
													: '',*/
											"subCategory" :  doc.properties["etm:Product"] ? doc.properties["etm:Product"]
											: ''|| doc.properties["etm:Marketing"] ? doc.properties["etm:Marketing"]
											: ''|| doc.properties["etm:Actuarial"] ? doc.properties["etm:Actuarial"]
											: ''|| doc.properties["etm:Sales"] ? doc.properties["etm:Sales"]
											: ''|| doc.properties["etm:OperationsAndServices"] ? doc.properties["etm:OperationsAndServices"]
											: ''|| doc.properties["etm:Investments"] ? doc.properties["etm:Investments"]
											: ''|| doc.properties["etm:AdminAndFacilities"] ? doc.properties["etm:AdminAndFacilities"]
											: ''|| doc.properties["etm:RiskManagement"] ? doc.properties["etm:RiskManagement"]
											: ''|| doc.properties["etm:Finance"] ? doc.properties["etm:Finance"]
											: ''|| doc.properties["etm:HRPolicy"] ? doc.properties["etm:HRPolicy"]
											: ''|| doc.properties["etm:InformationTechnology"] ? doc.properties["etm:InformationTechnology"]
											: ''|| doc.properties["etm:LegalAndCompliance"] ? doc.properties["etm:LegalAndCompliance"]
											: '',
											
											/*"sbu" : doc.properties["edcc:sbu"] ? doc.properties["edcc:sbu"]
													: '',*/
											"id" : doc.id
										});
							}
						}
						return details;
					}
					
					//end properties
					var setDetailsOfEachItem = function(segregatedByMime) {
						// count set on UI
						/*$scope.presentationCount = segregatedByMime.presentation.length;
						$scope.videoCount = segregatedByMime.video.length;*/
						$scope.documentCount = segregatedByMime.document.length;

						// setting all data in a variable
						/*$scope.presentationDetails = getPropertiesOf(segregatedByMime.presentation);
						$scope.videoDetails = getPropertiesOf(segregatedByMime.video);*/
						$scope.documentDetails = getPropertiesOf(segregatedByMime.document);
					}

					var segregateDataByMimeType = function(listOfItems) {
						var segregatedByMime = new Array();
						/*var presentation = new Array();
						var video = new Array();*/
						var document = new Array();

						for (var i = 0; i < listOfItems.length; i++) {
							var data = listOfItems[i].entry;
							if (data.content != undefined) {
								var mimeType = data.content.mimeType;
								// ppt
								if (mimeType != ''){
										
									document.push(data);
								}
							}
						}
						segregatedByMime.push({
							/*"presentation" : presentation,
							"video" : video,*/
							"document" : document
						});
						return segregatedByMime;
					}
					
					
//Shreyas
					
					var getAllItems = function() {

						var nodeId = $stateParams.id;

						var payload = {'cmisaction': "query", 
							       'statement': "SELECT * FROM cmis:document WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') ORDER BY cmis:creationDate DESC",
							       'maxItems':100,
							       'skipCount':0,};
				    
						$.ajax({

					    url : UtilService.alfrescoContextRoot() + '/alfresco/api/-default-/public/cmis/versions/1.1/browser',
					    type : 'POST',
					    xhrFields: {
					        'withCredentials': true //Tell browser to provide credentials
					    },
					    data: payload,
					    crossDomain: true,
					    success : function(data) {			
					    	
							if (data.results.length > 0) {
								
								    var listOfItems = data;
								    $scope.documentCount = data.results.length-1;
									
								} else {
									console.log('0 items in repository');
								}
								
							$scope.documentDetails = LatestCreatedService.getCmisPropertiesOf(data)[0];
							//console.log("allItemsDetails ",$scope.allItemsDetails.id);
					    	
					    },
					    error : function(request,error)
					    {
					    	console.log('error');
							$state.go('login');
					    }
					  });

					}
					
//					var getAllItems = function() {
//
//						var method = 'post';
//						var url = UtilService.alfrescoContextRoot()
//								+ "/alfresco/api/-default-/public/search/versions/1/search";
//						var body = {
//							"query" : {
//								"query" : "SITE:'" + siteId + "' AND (*)", // \"corporate-controller-bpri\"
//								"language" : "afts"
//							},
//							"paging" : {
//								"maxItems" : 100,
//								"skipCount" : 0
//							},
//							"include" : [ "properties" ],
//							/* "path" */
//							/* "aspectNames" */
//							"filterQueries" : [ {
//								"query" : "TYPE:'cm:content'"
//							}, {
//								"query" : "-cm:creator:system"
//							}, {
//								"query" : "-TYPE:'fm:post'"
//							} ],
//							/*
//							 * query specific to site here site ref is for c
//							 * BPRI site
//							 * "ANCESTOR:\"workspace://SpacesStore/9553fe6f-0c15-4996-928c-dc919b30ab13\""
//							 * "query" : "cm:creator:username"
//							 */
//							"sort" : [ {
//								"type" : "FIELD",
//								/*"field" : "cm:mimeType", commented by sandeep*/
//								"field" : "cm:created",
//								/*"field" : "cm:modified", commented by sandeep*/
//								/*"ascending" : "true"*/
//								"ascending" : "false"
//							} ],
//							'defaults' : {
//								'textAttributes' : [ 'cm:content', 'cm:name',
//										'cm:description', 'cm:title' ],
//								'defaultFTSOperator' : 'OR',
//								'defaultFTSFieldOperator' : 'OR',
//								'namespace' : 'cm',
//								'defaultFieldName' : '\"/\"'
//							}
//						};
//
//						var headers = {
//							authorization : "Basic "
//									+ btoa(sessionStorage.getItem('token'))
//						}
//
//						$http({
//							method : method,
//							url : url,
//							headers : headers,
//							data : body
//						})
//								.then(
//										function successCallback(response) {
//											if (response.status === 200) {
//												if (response.data.list.entries.length > 0) {
//													var listOfItems = response.data.list.entries;
//													var segregatedByMime = segregateDataByMimeType(listOfItems)[0];
//													setDetailsOfEachItem(segregatedByMime);
//												} else {
//													/*console.log('0 items in repository');*/
//												}
//											} else {
//												/*console.log('response other than 200 status code',response.status);*/
//											}
//										}, function errorCallback(response) {
//											/*console.log('error');*/
//											$state.go('login');
//										});
//
//					}
					
					//end added by sandeep

					angular.element(document).ready(
							function() {
								/*console.log("**********ViewController*******");*/
								$(this).scrollTop(0);
								init();
								/*if (sessionStorage.getItem('token')) {
									init();
								} else {
									sessionStorage.setItem('redirectUrl',$location.absUrl());
									console.log("View Unauthenticated");
									$state.go('login');
								}*/
							});
				});