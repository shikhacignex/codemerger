'use strict';

var SearchController = angularApp.controller('SearchController',
				function SearchController($scope, $state, $stateParams,SearchService, UtilService) {

					$scope.alfrescoContext = UtilService.alfrescoContextRoot();
					$scope.token = sessionStorage.getItem('token');

					// set initial index
					// Using variable to control the display
					// ng-show="" in HTML
					/*$scope.loadIndexPresentation = 4;
					$scope.loadIndexVideo = 4;
					$scope.loadIndexDocument = 4;*/
					$scope.loadIndexDocument = 4;

					// function to increase visible items
					$scope.ViewMore = function(item) {
						// don't increment if at the end of the list
						
						
						if (item === 'document') {
							if ($scope.loadIndexDocument < $scope.documentCount) {
								$scope.loadIndexDocument += 4;
								if ($scope.loadIndexDocument >= $scope.documentCount) {
									//$("#pstViewButton").addClass("disable-view-more-button");
									//$("#searchId").hide();
									$("#searchId").hide();
								}
							}
						}
					}

					var setDetailsOfEachItem = function(segregatedByMime) {
						// count set on UI
						/*$scope.presentationCount = segregatedByMime.presentation.length;
						$scope.videoCount = segregatedByMime.video.length;
						$scope.documentCount = segregatedByMime.document.length;*/
						$scope.documentCount = segregatedByMime.document.length;

						
						
						if ($scope.documentCount <= 4) {
							$("#pstViewButton").addClass("disable-view-more-button");
							$("#searchId").hide();
						}

						// getting the properties in an array by mime type
						// setting segregated data array on front end
						/*$scope.presentationDetails = SearchService
								.getPropertiesOf(segregatedByMime.presentation);
						$scope.videoDetails = SearchService
								.getPropertiesOf(segregatedByMime.video);
						$scope.documentDetails = SearchService
								.getPropertiesOf(segregatedByMime.document);*/
				$scope.documentDetails = SearchService.getPropertiesOf(segregatedByMime.document);
					}

					var segregateDataByMimeType = function(listOfItems) {
						var segregatedByMime = new Array();
						/*var presentation = new Array();
						var video = new Array();
						var document = new Array();*/
						var document = new Array();

						for (var i = 0; i < listOfItems.length; i++) {
							var data = listOfItems[i].entry;
							if (data.content != undefined) {
								var mimeType = data.content.mimeType;
								
								
								if (mimeType != ''){
									
									document.push(data);
								}
							}
						}
						segregatedByMime.push({
							/*"presentation" : presentation,
							"video" : video,*/
							"document" : document
						});
						return segregatedByMime;
					}

//					var init = function() {
//						var term = $stateParams.term;
//
//						if (term != '' && term != undefined && term != null) {
//							SearchService.searchDocuments(term,function(response) {
//												if (response != 'error') {
//													// seggregating all the
//													// response data by mime
//													// type
//													var segregatedByMime = segregateDataByMimeType(response)[0];
//													// setting details of all
//													// the documents on frontend
//													$scope.allItemsCount = response.length;
//													$scope.searchTerm = term;
//													setDetailsOfEachItem(segregatedByMime);
//												} else {
//													console.log('error');
//												}
//											});
//						} else {
//							$state.go('homeEtlife');
//						}
//					}

					//Shreyas
					var init = function() {
						var term = $stateParams.term;
						if (term != '' && term != undefined && term != null) {
							SearchService.searchCmisDocuments(term,function(response) {
								
								$scope.documentCount = response.results.length;
								
								if ($scope.documentCount <= 4) {
									$("#pstViewButton").addClass("disable-view-more-button");
									$("#searchId").hide();
								}
								
								if (response.results.length > 0) {
									$scope.documentDetails = SearchService.getCmisPropertiesOf(response);
									$scope.$apply();
								} else {
									$scope.documentDetails = "";
									console.log('0 items in repository');
									$scope.$apply();
								}
								
							});
						} else {
							$state.go('homeEtlife');
						}
					}
					
					angular.element(document).ready(function() {
						console.log("**********SearchController*******");
						$(this).scrollTop(0);
						init();
						/*if (sessionStorage.getItem('token')) {
							init();
						} else {
							sessionStorage.setItem('redirectUrl', $location.absUrl());
							console.log("Search Unauthenticated");
							$state.go('login');
						}*/
					});
				})