angularApp.service('SearchService',
	function($http, UtilService, siteId) {

		this.getPropertiesOf = function(docType) {
			var details = new Array();
			for (var i = 0; i < docType.length; i++) {
			  var doc = docType[i];
			  var createdDate = (new Date(doc.createdAt)).toDateString().split(" ");
				console.log("createdDate:",createdDate);
				var dayAndMonth = new Array();
				dayAndMonth.push({
							"day" : createdDate[2],
							"month" : createdDate[1],
							"year" : createdDate[3]
						});
				console.log("dayAndMonth",dayAndMonth);
				if (doc.name != null || doc.properties != null
					|| doc.id != null || doc.name != undefined
					|| doc.properties != undefined
					|| doc.id != undefined || doc.name != ''
					|| doc.properties != '' || doc.id != '') {

					details.push({
								"displayName" : doc.name.slice(0,doc.name.lastIndexOf(".")),
									   "name" : doc.name,
										 "by" : doc.properties["cm:author"] ? doc.properties["cm:author"]
													: '',
										/*"cby" : doc.properties["cm:creator"] ? doc.properties["cm:creator"]
													: '',	*/
								"description" : doc.properties["cm:description"] ? doc.properties["cm:description"]
													: '',
											/*"category" : doc.properties["edcc:Theme"] ? doc.properties["edcc:Theme"]
													: '',*/
								"subCategory" : doc.properties["etm:Product"] ? doc.properties["etm:Product"]
								: ''|| doc.properties["etm:Marketing"] ? doc.properties["etm:Marketing"]
								: ''|| doc.properties["etm:Actuarial"] ? doc.properties["etm:Actuarial"]
								: ''|| doc.properties["etm:Sales"] ? doc.properties["etm:Sales"]
								: ''|| doc.properties["etm:OperationsAndServices"] ? doc.properties["etm:OperationsAndServices"]
								: ''|| doc.properties["etm:Investments"] ? doc.properties["etm:Investments"]
								: ''|| doc.properties["etm:AdminAndFacilities"] ? doc.properties["etm:AdminAndFacilities"]
								: ''|| doc.properties["etm:RiskManagement"] ? doc.properties["etm:RiskManagement"]
								: ''|| doc.properties["etm:Finance"] ? doc.properties["etm:Finance"]
								: ''|| doc.properties["etm:HRPolicy"] ? doc.properties["etm:HRPolicy"]
								: ''|| doc.properties["etm:InformationTechnology"] ? doc.properties["etm:InformationTechnology"]
								: ''|| doc.properties["etm:LegalAndCompliance"] ? doc.properties["etm:LegalAndCompliance"]
								: '',
								  "createdOn" : dayAndMonth[0].day +" "+dayAndMonth[0].month+" "+dayAndMonth[0].year,
											/*"subCategorypa" : doc.properties["etl:Actuarial"] ? doc.properties["etl:Actuarial"]
													: '',
											"subCategorysp" : doc.properties["etl:Sales"] ? doc.properties["etl:Sales"]
													: '',*/
											/*"sbu" : doc.properties["edcc:sbu"] ? doc.properties["edcc:sbu"]
													: '',*/
											"id" : doc.id
										});
							}
						}
						return details;
					}
		//Shreyas
		this.searchCmisDocuments = function(term, callback) {

			// generating the search term and passing this term in
			// the search API
			//term = this.createSearchTerm(term);

			var payload = {'cmisaction': "query", 
				       'statement': "SELECT * FROM cmis:document WHERE CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND (cmis:name LIKE \'%"+term+"%\' OR cmis:description LIKE \'%"+term+"%\') ORDER BY cmis:name",
				       'maxItems':100,
				       'skipCount':0,};
	    
			$.ajax({

		    url : 'http://edelbsgcorpuat1.edelcap.com:8080/alfresco/api/-default-/public/cmis/versions/1.1/browser',
		    type : 'POST',
		    xhrFields: {
		        'withCredentials': true //Tell browser to provide credentials
		    },
		    data: payload,
		    crossDomain: true,
		    success : function(data) {			
		    	
						callback(data);
		    	
		    },
		    error : function(request,error)
		    {
		    	console.log('error');
				$state.go('login');
		    }
		  });

		}
		this.getCmisPropertiesOf = function(data) {
			
			var details = new Array();
			var subCat = "";
			for(var i=0;i<data.results.length;i++){
			
				var date = new Date(data.results[0].properties['cmis:creationDate'].value);
			
				//Checking category
				if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Marketing")!=-1){
					subCat="Marketing";
		    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Product")!=-1){
		    		subCat="Product";
		    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:LegalAndCompliance")!=-1){
		    		subCat="Legal & Compliance";
		    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:OperationsAndServices")!=-1){
		    		subCat="Operations & Services";
		    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Actuarial")!=-1){
		    		subCat="Actuarial";
		    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:AdminAndFacilities")!=-1){
		    		subCat="Admin & Facilities";
		    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Investments")!=-1){
		    		subCat="Investments";
		    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Finance")!=-1){
		    		subCat="Finance";
		    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:HRPolicy")!=-1){
		    		subCat="HR Policy";
		    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:RiskManagement")!=-1){
		    		subCat="Risk Management";
		    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:InformationTechnology")!=-1){
		    		subCat="Information Technology";
		    	}else if(data.results[i].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Sales")!=-1){
		    		subCat="Sales";
		    	}
			
				var displayname="";
				if(data.results[i].properties['cmis:name'].value.lastIndexOf(".")==-1){
					displayname=data.results[i].properties['cmis:name'].value;
				}else{
					displayname=data.results[i].properties['cmis:name'].value.slice(0, data.results[i].properties['cmis:name'].value.lastIndexOf("."));
				}
				
			details.push({
				"displayName" : displayname,
				"name" : data.results[i].properties['cmis:name'].value,
				"by" : data.results[i].properties['cmis:createdBy'].value ? data.results[i].properties['cmis:createdBy'].value
						: '',
				"description" : data.results[i].properties['cmis:description'].value ? data.results[i].properties['cmis:description'].value
						: '',
				/*"category" : doc.properties["edcc:Theme"] ? doc.properties["edcc:Theme"]
						: '',*/
				"subCategory" : subCat,
				/*"sbu" : doc.properties["edcc:sbu"] ? doc.properties["edcc:sbu"]
						: '',*/
				"createdOn" : date.toLocaleDateString()
						,
				"id" : data.results[i].properties['cmis:objectId'].value.slice(0, data.results[i].properties['cmis:objectId'].value.lastIndexOf(";"))
			});
			
			}
			return details; 
		}
					this.createSearchTerm = function(term) {
						var searchTerm
						searchTerm = '\"' + term + '\" OR cm:name:\"' + term
								+ '\" OR cm:title:\"' + term
								+ '\" OR cm:description:\"' + term
								+ '\" OR cm:content:\"' + term

						var splitTerm = term.split(/\s+/);
						for (var j = 0; j < splitTerm.length; j++) {
							searchTerm = searchTerm + ' OR \"' + splitTerm[j]
									+ '\" OR cm:name:\"' + splitTerm[j]
									+ '\" OR cm:title:\"' + splitTerm[j]
									+ '\" OR cm:description:\"' + splitTerm[j]
									+ '\" OR cm:content:\"' + splitTerm[j]
									+ '\"';
						}
						return searchTerm;
					}

					this.searchDocuments = function(term, callback) {

						// generating the search term and passing this term in
						// the search API
						term = this.createSearchTerm(term);

						var method = 'post';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/search/versions/1/search";
						var body = {
							"query" : {
								"query" : "SITE:'" + siteId + "' AND (" + term
										+ ")",
								"language" : "afts"
							},
							"paging" : {
								"maxItems" : 100,
								"skipCount" : 0
							},
							"include" : [ "properties" ],
							"filterQueries" : [ {
								"query" : "TYPE:'cm:content'"
							}, {
								"query" : "-cm:creator:system"
							}, {
								"query" : "-TYPE:'fm:post'"
							} ],
							'defaults' : {
								'textAttributes' : [ 'cm:content', 'cm:name',
										'cm:description', 'cm:title' ],
								'defaultFTSOperator' : 'OR',
								'defaultFTSFieldOperator' : 'OR',
								'namespace' : 'cm',
								'defaultFieldName' : '\"/\"'
							}
						};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {

							if (response.status === 200) {
								var entries = response.data.list.entries;
								callback(entries);
							} else {
								callback("error");
							}

						}, function errorCallback(response) {
							console.log(response);
							callback("error");
						});

					}
				})