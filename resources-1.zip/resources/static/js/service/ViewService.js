angularApp
		.service(
				'ViewService',
				function($http, siteId, UtilService) {

					/* temporary functionality for comment starts */

					/**
					 * creating a temporary authentication ticket using admin
					 * credentials after authentication is successful the ticket
					 * is passed as callbacks and used for adding the current
					 * logged in user in SiteContributor group. After adding the
					 * user in group, comment is then posted on the selected
					 * item or node. After that user is removed from the group
					 * and the admin ticket is deleted.
					 */

					this.tempAdminTicket = function(callback) {
						console.log("Step 2");
						// getting the temporary admin ticket
						var method = 'post';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/authentication/versions/1/tickets";
						var body = {
							'userId' : "admin",
							'password' : "admin@etlife"
						};
						var ticket = $http({
							method : method,
							url : url,
							data : body
						}).then(function successCallback(response) {
							callback(response.data.entry.id);
						}, function errorCallback(response) {
							callback(response.data.error.briefSummary);
						});

					}
					//
					this.addUserAsContributor = function(callback) {

						this.tempAdminTicket(function(ticket) {
									console.log("Step 4");
									// using the temp ticket generated, adding
									// the user to contributors group
									var method = 'post';
									var url = UtilService.alfrescoContextRoot()
											+ "/alfresco/api/-default-/public/alfresco/versions/1/sites/"
											+ siteId + "/members";
									var userId = sessionStorage.getItem('userId');
									var headers = {authorization : "Basic " + btoa(ticket)}
									var body = {
										'role' : "SiteContributor",
										'id' : userId
									};

									var response = $http({
										method : method,
										url : url,
										headers : headers,
										data : body
									}).then(function successCallback(response) {
										if (response.status === 201) {
											callback(true, ticket);
										}
									}, function errorCallback(response) {
										if (response.status === 409) {
											callback(false, ticket);
										}
									});

								})
					}
					//
					this.writeComment = function(id, content, callback) {
						this.addUserAsContributor(function(bool, ticket) {
									// after adding user to group
									// write the comment implementation
									var method = 'post';
									var url = UtilService.alfrescoContextRoot()
											+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/"
											+ id
											+ "/comments?fields=id,content,canDelete,createdBy";
									var body = {
										"content" : content
												};
									var headers = {
										authorization : "Basic "+ btoa(sessionStorage.getItem('token'))
									}

									$http({
										method : method,
										url : url,
										headers : headers,
										data : body
									})
									.then(function successCallback(response) {
											if (response.status === 201) {
												var entry = response.data.entry;
												callback(bool,ticket,entry);
												} else {
													console.log('!= 200');
														}
													},
										  function errorCallback(response) {
												callback(bool, ticket,response.status);
													});
								});
					}
					//
					this.tempAuthAndWriteComment = function(id, content,
							callback) {
						this.writeComment(id,content,
										function(bool, ticket, entry) {
											// if true : user successfully added
											// to group
											// now removing the user from group
											if (bool) {

											}
											// if false: user is already a
											// member of group
											// no need t remove user from group
											else {
												// callback(ticket, entry);
											}

											// delete the user from the
											// group
											var method = 'post';
											var userId = sessionStorage.getItem('userId');
											var url = UtilService
													.alfrescoContextRoot()
													+ "/alfresco/api/-default-/public/alfresco/versions/1/sites/"
													+ siteId
													+ "/members/"
													+ userId;
											var headers = {
												authorization : "Basic "
														+ btoa(ticket)
											}

											$http({
												method : method,
												url : url,
												headers : headers
											})
													.then(
															function successCallback(
																	response) {
																if (response.status === 204) {
																	callback(
																			ticket,
																			entry);
																}
															},
															function errorCallback(
																	response) {
																if (response.status === 400) {
																	callback(ticket,entry);
																}

															});
										})
					}

					// passing the id of the node and comment text
					// deleting the temp ticket of admin
					this.comment = function(id, commentText, callback) {
						this
								.tempAuthAndWriteComment(
										id,
										commentText,
										function(ticket, entry) {
											// delete the temp admin ticket
											// created
											var method = 'delete';
											var url = UtilService
													.alfrescoContextRoot()
													+ "/alfresco/api/-default-/public/authentication/versions/1/tickets/-me-";
											var headers = {
												authorization : "Basic "
														+ btoa(ticket)
											}

											$http({
												method : method,
												url : url,
												headers : headers
											}).then(
													function successCallback(
															response) {
														callback(entry);
													},
													function errorCallback(
															response) {
														callback(entry);
													});
										});
					}
					/* temporary functionality for comment ends */
					this.convertTime24to12= function(time24){
						var tmpArr = time24.split(':'), time12;
						if(+tmpArr[0] == 12) {
						time12 = tmpArr[0] + ':' + tmpArr[1] + ' PM';
						} else {
						if(+tmpArr[0] == 00) {
						time12 = '12:' + tmpArr[1] + ' AM';
						} else {
						if(+tmpArr[0] > 12) {
						time12 = (+tmpArr[0]-12) + ':' + tmpArr[1] + ' PM';
						} else {
						time12 = (+tmpArr[0]) + ':' + tmpArr[1] + ' AM';
						}
						}
						}
						return time12;
						}

				})