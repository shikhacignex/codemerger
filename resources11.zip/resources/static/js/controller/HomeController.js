'use strict';

var HomeController = angularApp
.controller(
		'HomeController',
		function HomeController($scope, $stateParams, $rootScope,
				$http, $state, $location, siteId, UtilService,
				AlertService, $window, ControllerService, DataService, LatestCreatedService) {

			$scope.alfrescoContext = 'http://edelbsgcorpuat1.edelcap.com:8080';
			$scope.token = sessionStorage.getItem('token');

			// set initial index
			// Using variable to control the display
			// ng-show="" in HTML
			/*
			 * $scope.loadIndexPresentation = 4; $scope.loadIndexVideo =
			 * 4;
			 */
			$scope.loadIndexDocument = 4;

			// function to increase visible items
			$scope.ViewMore = function(item) {
				// don't increment if at the end of the list
				/*
				 * if (item === 'presentation') { if
				 * ($scope.loadIndexPresentation <
				 * $scope.presentationCount) {
				 * $scope.loadIndexPresentation += 4; if
				 * ($scope.loadIndexPresentation >=
				 * $scope.presentationCount) {
				 * $("#pstViewButton").addClass(
				 * "disable-view-more-button"); } } } else if (item ===
				 * 'video') { if ($scope.loadIndexVideo <
				 * $scope.videoCount) { $scope.loadIndexVideo += 4; if
				 * ($scope.loadIndexVideo >= $scope.videoCount) {
				 * $("#vidViewButton").addClass(
				 * "disable-view-more-button"); }
				 *  } } else
				 */
				if (item === 'document') {
					if ($scope.loadIndexDocument < $scope.documentCount) {
						$scope.loadIndexDocument += 4;
						if ($scope.loadIndexDocument >= $scope.documentCount) {
							$("#docViewButton").addClass(
							"disable-view-more-button");
						}
					}
				}

			};

			$scope.onFeedbackSubmitCommentClick = function() {
				if (sessionStorage.getItem('token')) {
					var text = $scope.feedbackText;
					var feedbackType = $scope.feedbackDropdownSelectedOption.name;
					if (text != null || text != undefined || text != ''
						|| text != "") {
						var urlOnPage = $location;
						var userId = sessionStorage.getItem('userId');
						var method = 'post';
						var url = UtilService.contextRoot()
						+ "/api/feedback";
						text = text.trim();
						var body = {
								"username" : String(userId),
								"url" : String(urlOnPage.$$absUrl),
								"feedbackText" : String(text),
								"feedbackType" : String(feedbackType)
						};

						var headers = {
								'Content-Type' : 'application/json'
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {
							console.log(response);
							if (response.status === 200) {
								console.log('status 200');
							} else {
								console.log('status != 200');
							}
						}, function errorCallback(response) {
							console.log('error', response);
						});
					}
					$scope.feedbackText = '';
					$scope.feedbackDropdownSelectedOption = $scope.feedbackDropdownOptions[0];
					document.getElementById("#myModal");
				} else {
					state.go('login');
				}
			}

			$scope.onMainSearchClick = function() {
				var text = $scope.mainSearchText;
				$scope.selectedMenuItem = '';
				$state.go('search', {
					term : text
				});
			}

			var initilizeFeedbackDropdown = function() {
				$scope.feedbackDropdownOptions = [ {
					name : "I like something",
					id : 1
				}, {
					name : "I dislike something",
					id : 2
				}, {
					name : "I have a suggestion",
					id : 3
				} ];
				$scope.feedbackDropdownSelectedOption = $scope.feedbackDropdownOptions[0];
			};

			$scope.initApp = function() {
				initilizeFeedbackDropdown();

			};

			$scope.productOnclick = function() {
				$state.go('filter-search', {
					term : 'productOnclick'
				});	
				$rootScope.currentAspect="Product";
			}// close of productOnclick

			$scope.marketingOnclick = function() {
				$state.go('filter-search', {
					term : 'marketingOnclick'
				});	
				$rootScope.currentAspect="Marketing";
			}// close of marketingOnclick

			$scope.PerformActuarialAnalysisOnclick = function() {
				$state.go('filter-search', {
					term : 'PerformActuarialAnalysisOnclick'
				});
				$rootScope.currentAspect="Actuarial";
			}

			$scope.SalesProductsOnclick = function() {

				 alert("I am inside the SalesProductsOnclick");
				$state.go('filter-search', {
					term : 'SalesProductsOnclick'
				});
				$rootScope.currentAspect="Sales";
			}
			/*$scope.OperationsAndServicesOnclick = function() {

						// alert("I am inside the SalesProductsOnclick");
						$state.go('filter-search', {
							term : 'OperationsAndServicesOnclick'
						});
					}
			 */
			$scope.OperationsAndServicesOnclick = function() {

				 alert("I am inside the OperationsAndServicesOnclick");
				$state.go('filter-search', {
					term : 'OperationsAndServicesOnclick'
				});
				$rootScope.currentAspect="OperationsAndServices";
			}
			$scope.ManageInvestmentsOnclick = function() {

				 alert("I am inside the SalesProductsOnclick");
				$state.go('filter-search', {
					term : 'ManageInvestmentsOnclick'
				});
				$rootScope.currentAspect="Investments";
			}
			$scope.AdminAndFacilitiesOnclick = function() {

				 alert("I am inside the SalesProductsOnclick");
				$state.go('filter-search', {
					term : 'AdminAndFacilitiesOnclick'
				});
				$rootScope.currentAspect="AdminAndFacilities";
			}
			$scope.RiskManagementOnclick = function() {

				 alert("I am inside the SalesProductsOnclick");
				$state.go('filter-search', {
					term : 'RiskManagementOnclick'
				});
				$rootScope.currentAspect="RiskManagement";
			}
			$scope.FinanceOnclick = function() {

				 alert("I am inside the SalesProductsOnclick");
				$state.go('filter-search', {
					term : 'FinanceOnclick'
				});
				$rootScope.currentAspect="Finance";
				
			}

			$scope.HumanResourcesOnclick = function() {

				alert("I am inside the SalesProductsOnclick");
				$state.go('filter-search', {
					term : 'HumanResourcesOnclick'
				});
				$rootScope.currentAspect="HRPolicy";
			}
			$scope.InformationTechnologyOnclick = function() {

				 alert("I am inside the SalesProductsOnclick");
				$state.go('filter-search', {
					term : 'InformationTechnologyOnclick'
				});
				$rootScope.currentAspect="InformationTechnology";
			}
			$scope.LegalAndComplianceOnclick = function() {

				 alert("I am inside the SalesProductsOnclick");
				$state.go('filter-search', {
					term : 'LegalAndComplianceOnclick'
				});
				$rootScope.currentAspect="LegalAndCompliance";
			}
			$scope.LearningAndDevelopmentOnclick = function() {

				 alert("I am inside the SalesProductsOnclick");
				$state.go('filter-search', {
					term : 'LearningAndDevelopmentOnclick'
				});
				$rootScope.currentAspect="LearningAndDevelopment";
			}


			$scope.mostReadOnClick = function() {

				 alert("I am inside the SalesProductsOnclick");
				$state.go('mostRead', {
					term : 'mostReadOnClick'
				});
			}

			$scope.LCDocOnClick = function() {

				 alert("I am inside the SalesProductsOnclick");
				$state.go('LCDoc', {
					term : 'LCDocOnClick'
				});
			}

			/***********************************************************
			 * function to decrease visible items $scope.showLess =
			 * function() { // don't decrement if at the start of the
			 * list if ($scope.loadIndexPresentation > 2) {
			 * $scope.loadIndexPresentation -= 2; } };
			 **********************************************************/

			var getPropertiesOf = function(docType) {
				var details = new Array();
				for (var i = 0; i < docType.length; i++) {
					var doc = docType[i];
					if (doc.name != null || doc.properties != null
							|| doc.id != null || doc.name != undefined
							|| doc.properties != undefined
							|| doc.id != undefined || doc.name != ''
								|| doc.properties != '' || doc.id != '') {

						details
						.push({
							"displayName" : doc.name.slice(0,
									doc.name.lastIndexOf(".")),
									"name" : doc.name,
									"by" : doc.properties["cm:author"] ? doc.properties["cm:author"]
						: '',
						"description" : doc.properties["cm:description"] ? doc.properties["cm:description"]
									: '',
									/*
									 * "category" :
									 * doc.properties["edcc:Theme"] ?
									 * doc.properties["edcc:Theme"] :
									 * '',
									 */
									"subCategory" : doc.properties["etl:Product"] ? doc.properties["etl:Product"]	: '' ||
											doc.properties["etl:EdelMarketing"] ? doc.properties["etl:EdelMarketing"]	: '' ||
													doc.properties["etl:Actuarial"] ? doc.properties["etl:Actuarial"]	: '' || 
															doc.properties["etl:Sales"] ? doc.properties["etl:Sales"] : '' || 
																	doc.properties["etl:OperationsAndServices"] ? doc.properties["etl:OperationsAndServices"] : ''
																		|| doc.properties["etl:InvestmentManagement"] ? doc.properties["etl:InvestmentManagement"]
																	: ''
																		|| doc.properties["etl:AdminAndFacilities"] ? doc.properties["etl:AdminAndFacilities"]
																		: ''
																			|| doc.properties["etl:Finance"] ? doc.properties["etl:Finance"]
																		: ''
																			|| doc.properties["etl:RiskManagement"] ? doc.properties["etl:RiskManagement"]
																			: ''
																				|| doc.properties["etl:HRPloicy"] ? doc.properties["etl:HRPloicy"]
																			: ''
																				|| doc.properties["etl:InformationTechnology"] ? doc.properties["etl:InformationTechnology"]
																				: ''
																					|| doc.properties["etl:LegalAndCompliance"] ? doc.properties["etl:LegalAndCompliance"]
																				: '',
																				/*
																				 * "sbu" :
																				 * doc.properties["edcc:sbu"] ?
																				 * doc.properties["edcc:sbu"] : '',
																				 */
																				"id" : doc.id
						});
					}
				}
				return details;
			}

			var setDetailsOfEachItem = function(segregatedByMime) {
				// count set on UI
				/*
				 * $scope.presentationCount =
				 * segregatedByMime.presentation.length;
				 * $scope.videoCount = segregatedByMime.video.length;
				 */
				$scope.documentCount = segregatedByMime.document.length;

				// setting all data in a variable
				/*
				 * $scope.presentationDetails =
				 * getPropertiesOf(segregatedByMime.presentation);
				 * $scope.videoDetails =
				 * getPropertiesOf(segregatedByMime.video);
				 */
				$scope.documentDetails = getPropertiesOf(segregatedByMime.document);
			}

			var segregateDataByMimeType = function(listOfItems) {
				var segregatedByMime = new Array();
				/*
				 * var presentation = new Array(); var video = new
				 * Array();
				 */
				var document = new Array();

				for (var i = 0; i < listOfItems.length; i++) {
					var data = listOfItems[i].entry;
					if (data.content != undefined) {
						var mimeType = data.content.mimeType;
						// ppt
						if (mimeType != '') {

							document.push(data);
						}
					}
				}
				segregatedByMime.push({
					/*
					 * "presentation" : presentation, "video" : video,
					 */
					"document" : document
				});
				return segregatedByMime;
			}

			/* commented by shikha for code merger
			var getAllItems = function() {

				var method = 'post';
				var url = 'http://edelbsgcorpuat1.edelcap.com:8080'
				+ "/alfresco/api/-default-/public/search/versions/1/search";
				var body = {
						"query" : {
							"query" : "SITE:'" + siteId + "' AND (*)", // \"corporate-controller-bpri\"
							"language" : "afts"
						},
						"paging" : {
							"maxItems" : 100,
							"skipCount" : 0
						},
						"include" : [ "properties" ],
						
						"filterQueries" : [ {
							"query" : "TYPE:'cm:content'"
						}, {
							"query" : "-cm:creator:system"
						}, {
							"query" : "-TYPE:'fm:post'"
						} ],
						
						"sort" : [ {
							"type" : "FIELD",
							"field" : "cm:mimeType",
							"ascending" : "true"
						} ],
						'defaults' : {
							'textAttributes' : [ 'cm:content', 'cm:name',
								'cm:description', 'cm:title' ],
								'defaultFTSOperator' : 'OR',
								'defaultFTSFieldOperator' : 'OR',
								'namespace' : 'cm',
								'defaultFieldName' : '\"/\"'
						}
				};

				var headers = {
						authorization : "Basic "
							+ btoa(sessionStorage.getItem('token'))
				}

				$http({
					method : method,
					url : url,
					headers : headers,
					data : body
				})
				.then(
						function successCallback(response) {
							if (response.status === 200) {
								if (response.data.list.entries.length > 0) {
									var listOfItems = response.data.list.entries;
									var segregatedByMime = segregateDataByMimeType(listOfItems)[0];
									setDetailsOfEachItem(segregatedByMime);
								} else {
									console
									.log('0 items in repository');
								}
							} else {
								console
								.log(
										'response other than 200 status code',
										response.status);
							}
						}, function errorCallback(response) {
							console.log('error');
							$state.go('login');
						});

			}

			*/
			
			var getAllItems = function() {

				var nodeId = $stateParams.id;

				var payload = {'cmisaction': "query", 
					       'statement': "SELECT * FROM cmis:document WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') ORDER BY cmis:creationDate DESC",
					       'maxItems':100,
					       'skipCount':0,};
		    
				$.ajax({

			    url : 'http://edelbsgcorpuat1.edelcap.com:8080' + '/alfresco/api/-default-/public/cmis/versions/1.1/browser',
			    type : 'POST',
			    xhrFields: {
			        'withCredentials': true //Tell browser to provide credentials
			    },
			    data: payload,
			    crossDomain: true,
			    success : function(data) {			
			    	
					if (data.results.length > 0) {
						
						    var listOfItems = data;
							
						} else {
							console.log('0 items in repository');
						}
						
					$scope.documentDetails = LatestCreatedService.getCmisPropertiesOf(data);
					console.log("HomeController method end");
			    	
			    },
			    error : function(request,error)
			    {
			    	console.log('error');
					$state.go('login');
			    }
			  });

			}
			
			$scope.open = function() {
				console.log('opening pop up');
				var modalInstance = $modal.open({
					templateUrl : 'html/mostRead.html',
					controller : 'mostReadController',
				});
			}
			/*
			 * $window.open({ url : '/mostRead', templateUrl :
			 * 'html/mostRead.html', controller: 'mostReadController'
			 * });
			 */
			console.log("popup open")

			//Shreyas
					var init = function() {
						getAllItems();
						var id = $stateParams.id;
						var fileName = $stateParams.fileName;
						var author = $stateParams.author;
						$scope.author = $stateParams.author;

						if (id === null || id === undefined || id === '') {
							$state.go('homeEtlife');
						} else {
							$.ajax({

							    url : 'http://edelbsgcorpuat1.edelcap.com:8080'	+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/" + id,
							    type : 'GET',
							    xhrFields: {
							        'withCredentials': true //Tell browser to provide credentials
							    },
							    //data: payload,
							    //crossDomain: true,
							    success : function(response) {
							    	console.log(JSON.stringify(response));
							    	$scope.likeStatus = true;

									var createdDate = (new Date(response.entry.createdAt)).toDateString().split(" ");
										
									if(response.entry.properties["etm:Product"]){
										var subCategory = response.entry.properties["etm:Product"];
										$scope.subCategorycopy = response.entry.properties["etm:Product"];
									}else if(response.entry.properties["etm:Marketing"]){
										var subCategory = response.entry.properties["etm:Marketing"];
										$scope.subCategorycopy = response.entry.properties["etm:Marketing"];
									}else if(response.entry.properties["etm:Actuarial"]){
										var subCategory = response.entry.properties["etm:Actuarial"];
										$scope.subCategorycopy = response.entry.properties["etm:Actuarial"];
									}else if(response.entry.properties["etm:Sales"]){	
										var subCategory = response.entry.properties["etm:Sales"];
										$scope.subCategorycopy = response.entry.properties["etm:Sales"];
									} else if(response.entry.properties["etm:OperationsAndServices"]){
										var subCategory = response.entry.properties["etm:OperationsAndServices"];
										$scope.subCategorycopy = response.entry.properties["etm:OperationsAndServices"];
									}else if(response.entry.properties["etm:Investments"]){
										var subCategory = response.entry.properties["etm:Investments"];
										$scope.subCategorycopy = response.entry.properties["etm:Investments"];
									}else if(response.entry.properties["etm:AdminAndFacilities"]){
										var subCategory = response.entry.properties["etm:AdminAndFacilities"];
										$scope.subCategorycopy = response.entry.properties["etm:AdminAndFacilities"];
									}else if(response.entry.properties["etm:RiskManagement"]){
										var subCategory = response.entry.properties["etm:RiskManagement"];
										$scope.subCategorycopy = response.entry.properties["etm:RiskManagement"];
									}else if(response.entry.properties["etm:Finance"]){
										var subCategory = response.entry.properties["etm:Finance"];
										$scope.subCategorycopy = response.entry.properties["etm:Finance"];
									}else if(response.entry.properties["etm:HRPolicy"]){
										var subCategory = response.entry.properties["etm:HRPolicy"];
										$scope.subCategorycopy = response.entry.properties["etm:HRPolicy"];
									}else if(response.entry.properties["etm:InformationTechnology"]){
										var subCategory = response.entry.properties["etm:InformationTechnology"];
										$scope.subCategorycopy = response.entry.properties["etm:InformationTechnology"];
									}else if(response.entry.properties["etm:LegalAndCompliance"]){
										var subCategory = response.entry.properties["etm:LegalAndCompliance"];
										$scope.subCategorycopy = response.entry.properties["etm:LegalAndCompliance"];
									}

										var description = response.entry.properties["cm:description"];

										var dayAndMonth = new Array();
										dayAndMonth
												.push({
													"day" : createdDate[2],
													"month" : createdDate[1],
													"year" : createdDate[3]
												});

										setDetails(id, fileName,
												$scope.author,
												description,
												dayAndMonth);

										previewDocument(id,
												fileName);

										getMoreBestPractices(id,
												fileName);

										//getAllLikes(id);
										getAllComments(id);
									
							    },
							    error : function(request,error)
							    {
							    	console.log('error');
							    }
							  });
						}
					}

			angular.element(document).ready(
					function() {
						console.log("**********HomeController*******");
						console.log("header shown");
						$("#headerId").show();
						$(this).scrollTop(0);
						console.log("init method calling now");
						//Shreyas
						init();
						/*if (sessionStorage.getItem('token')) {
							init();
						} else {
							sessionStorage.setItem('redirectUrl',
									$location.absUrl());
							console.log("View Unauthenticated");
							$state.go('login');
						}*/
					});
		});