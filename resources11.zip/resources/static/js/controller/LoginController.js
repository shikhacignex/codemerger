var LoginController = angularApp
		.controller(
				'LoginController',
				function LoginController($scope, $rootScope, $window, $http,
						$location, $state,$stateParams,siteId, UtilService, CommonDataService,
						UserDataService,LatestCreatedService) {
					

					$scope.showBadCredentials = true;

					var clearInputFields = function() {
					}

					var authenticate = function(credentials, callback) {

						var method = 'post';
						var url = 'http://edelbsgcorpuat1.edelcap.com:8080'
								+ "/alfresco/api/-default-/public/authentication/versions/1/tickets";
					
						var body = {
						'userId' : $scope.credentials.username,
						'password' : $scope.credentials.password
						};
					
						UtilService.doAjax(
										method,
										url,
										body,
										function(response) {
											if (response.status === 201) {
												$rootScope.authenticated = true;
												$rootScope.displayUserName = $scope.credentials.username;
											   console.log("response" + response);
												sessionStorage.setItem('token',response.data.entry.id);
												sessionStorage.setItem('userId',response.data.entry.userId);
												
												
												$rootScope.tokenIH=response.data.entry.id;
												//console.log("tocken ",$scope.tokenIH);
												
												
												
											} else {
												$rootScope.authenticated = false;
											}
											callback
													&& callback($rootScope.authenticated);
										});
					}
					
					
					/*$scope.onPopup = function ($scope, $window) {
				           $scope.OpenPopupWindow = function () {
				               $window.open("#mostRead", "popup", "width=300,height=200,left=10,top=150");
				        	   $state.go('mostRead');
				           }
				       }*/
					
					
					// ############### MostRead start
/* commented by shikha
					$scope.LCDoc = function() {

						//alert("Hi, I am in LCDoc with LatestCreatedController");
						var nodeId = $stateParams.id;
						// var commentId = event.target.id;

						var method = 'post';
						// http://localhost:8080/alfresco/s/share-stats/select-audits?type=mostread&module=document&sites=bsg&limit=1000
						var url = 'http://edelbsgcorpuat1.edelcap.com:8080'
								  + "/alfresco/api/-default-/public/search/versions/1/search";
								
						var body = {
								"query" : {
									"query" : "SITE:'" + siteId + "' AND (*)", // \"corporate-controller-bpri\"
									"language" : "afts"
								},
								
									"paging" : {
									"maxItems" : 100,
									"skipCount" : 0
								},
								"include" : [ "properties" ],
							
								"filterQueries" : [ {
									"query" : "TYPE:'cm:content'"
								}, {
									"query" : "-cm:creator:system"
								}, {
									"query" : "-TYPE:'fm:post'"
								} ],
								
								"sort" : [ {
									"type" : "FIELD",
									
									"field" : "cm:created",
									
									"ascending" : "false"
								} ],
								'defaults' : {
									'textAttributes' : [ 'cm:content', 'cm:name',
											'cm:description', 'cm:title' ],
									'defaultFTSOperator' : 'OR',
									'defaultFTSFieldOperator' : 'OR',
									'namespace' : 'cm',
									'defaultFieldName' : '\"/\"'
								}
							};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {
							console.log(response);
							if (response.status === 200) {
								console.log('Most Viewed Docs', response);
								console.log("response.length",response.length);
								if (response.data.list.entries.length > 0) {
									var listOfItems = response.data.list.entries;
									
									$scope.allItemsCount = response.data.list.entries.length;
									
									
									
									$rootScope.allItemsDetails = LatestCreatedService.getPropertiesOf(response);
									console.log("$rootScope.allItemsDetails",$rootScope.allItemsDetails[0].by);
									
									
									$rootScope.by=$rootScope.allItemsDetails[0].by;
									$rootScope.idIh=$rootScope.allItemsDetails[0].id;
									$rootScope.nameIh=$rootScope.allItemsDetails[0].name;
									$rootScope.createdOn=$rootScope.allItemsDetails[0].createdOn;
									$rootScope.subCategory=$rootScope.allItemsDetails[0].subCategory;
									$rootScope.displayNameIH=$rootScope.allItemsDetails[0].displayName;
									
								} else {
									console.log('0 items in repository');
								}
							
							} else {
								console.log('status != 200');
							}
						}, function errorCallback(response) {
							console.log('error');
						});
					}

					*/
					
					// added by shikha
					$scope.LCDoc = function() {

						var nodeId = $stateParams.id;

						var payload = {'cmisaction': "query", 
							       'statement': "SELECT * FROM cmis:document WHERE NOT(cmis:objectTypeId = 'D:fm:post') AND CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') ORDER BY cmis:creationDate DESC",
							       'maxItems':100,
							       'skipCount':0,};
				    
						$.ajax({

					    url : 'http://edelbsgcorpuat1.edelcap.com:8080' + '/alfresco/api/-default-/public/cmis/versions/1.1/browser',
					    type : 'POST',
					    xhrFields: {
					        'withCredentials': true //Tell browser to provide credentials
					    },
					    data: payload,
					    crossDomain: true,
					    success : function(data) {
					    	if(data.results.length>0){
						    	if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Marketing")!=-1){
						    		$rootScope.subCategory="Marketing";
						    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Product")!=-1){
						    		$rootScope.subCategory="Product";
						    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:LegalAndCompliance")!=-1){
						    		$rootScope.subCategory="Legal & Compliance";
						    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:OperationsAndServices")!=-1){
						    		$rootScope.subCategory="Operations & Services";
						    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Actuarial")!=-1){
						    		$rootScope.subCategory="Actuarial";
						    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:AdminAndFacilities")!=-1){
						    		$rootScope.subCategory="Admin & Facilities";
						    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Investments")!=-1){
						    		$rootScope.subCategory="Investments";
						    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Finance")!=-1){
						    		$rootScope.subCategory="Finance";
						    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:HRPolicy")!=-1){
						    		$rootScope.subCategory="HR Policy";
						    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:RiskManagement")!=-1){
						    		$rootScope.subCategory="Risk Management";
						    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:InformationTechnology")!=-1){
						    		$rootScope.subCategory="Information Technology";
						    	}else if(data.results[0].properties['cmis:secondaryObjectTypeIds'].value.indexOf("P:etm:Sales")!=-1){
						    		$rootScope.subCategory="Sales";
						    	}
						    	
						    	var date = new Date(data.results[0].properties['cmis:creationDate'].value);
						        $rootScope.by=data.results[0].properties['cmis:createdBy'].value;
								$rootScope.idIh=data.results[0].properties['cmis:objectId'].value.slice(0, data.results[0].properties['cmis:objectId'].value.lastIndexOf(";"));
								$rootScope.nameIh=data.results[0].properties['cmis:name'].value;
								$rootScope.m=date.toLocaleDateString();
								//$rootScope.subCategory=$rootScope.allItemsDetails[0].subCategory;
								$rootScope.displayNameIH=data.results[0].properties['cmis:name'].value.slice(0, data.results[0].properties['cmis:name'].value.lastIndexOf("."));
								$rootScope.$apply();
								$('#onload').modal('show');
					    	}
							
					    },
					    error : function(request,error)
					    {
					    	console.log('error');
					    }
					  });
					}
					// ############### MostRead End
					
					
					//$window.open('https://www.google.com', '_blank');
					
					
					//Shreyas SSO Kerberos
					$scope.kerberosLogin = function(){
						
					//	$state.go('homeEtlife');
					//	$scope.LCDoc();
						$.ajax({
						    url : 'http://edelbsgcorpuat1.edelcap.com:9090/authenticate',
						  //  url : 'http://localhost:9090/authenticate',
						    type : 'GET',
						    xhrFields: {
						        'withCredentials': true //Tell browser to provide credentials
						    },
						    success : function (response) {
						    	$scope.ssoKerb = JSON.parse(response)[0].authenticated;
						        if($scope.ssoKerb==true){
						        	$rootScope.authenticated = true;
						        	$rootScope.displayUserName="User";
						        	var redirectUrl = sessionStorage.getItem('redirectUrl');
						        	if (redirectUrl	&& redirectUrl.indexOf("login") != true
						        			&& redirectUrl.indexOf("#") == true) {
						        		$window.location.href = redirectUrl;
						        	} else {
						        		console.log("authenticated");
						        		$state.go('homeEtlife');
						        		$scope.LCDoc();
						        		//$('#onload').modal('show');      moved to lcdoc function 
						        		$scope.commentText = '';
						        	}
						        }else{
									console.log("not authenticated");
									console.log("Errors " + JSON.stringify(response));
									$scope.error = "Not authenticated, Incorrect username/password !";
									$state.go('login');
								}
						    },
						    error : function(request,error)
						    {
						    	$rootScope.authenticated = false;
						    	console.log("not authenticated");
								$scope.error = "Not authenticated";
								$state.go('login');
						    }
						  });
						
					}
					
					
					$scope.kerberosLogin();

					$scope.onLoginClick = function() {

						console.log("Login Click");
						$scope.credentials.username = document
								.getElementById("username").value;
						$scope.credentials.password = document
								.getElementById("password").value;

						if (document.getElementById("password").value.length > 0) {
							authenticate($scope.credentials,
									function() {
										if ($rootScope.authenticated) {
											console.log("authenticated");
											$rootScope.displayUserName = $scope.credentials.username;
											var redirectUrl = sessionStorage.getItem('redirectUrl');
											if (redirectUrl	&& redirectUrl.indexOf("login") != true
													&& redirectUrl.indexOf("#") == true) {
												/*$state.go('mostRead');*/
												$window.location.href = redirectUrl;
											} else {
												// $state.go('home');
												$state.go('homeEtlife');
												    
												console.log("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
												$scope.LCDoc();
												
												$('#onload').modal('show');
												
											/*	var modalInstance=$modal.open({
													templateUrl: 'lcdoc.html',
														controller:'HomeController'
															
												});
												*/
												
												
												
												
												$scope.commentText = '';
												var commentVar = setTimeout(commentFunc, 20);
												
												function commentFunc() {
													console.log("inside the pop up after dalay__________________");
													//$scope.LCDoc();
												}
												
												
												
												
												
												
											}
										} else {
											console.log("not authenticated");
											$scope.error = "Not authenticated, Incorrect username/password !";
											$state.go('login');
										}
									});
						} else {
							$rootScope.authenticated = false;
						}
						
						
						    
						   
						    
					}

					angular.element(document).ready(function() {		
						$("#headerId").hide();
						console.log("**********LoginController***********");
						console.log("header hidded");
						$scope.credentials = {};
//						if (sessionStorage.getItem('token')) {
//							$state.go('login');
//						}
					});
					
					

				});
