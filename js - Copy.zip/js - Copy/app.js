'use strict';

var angularApp = angular.module('angularApp', [ 'ui.router', 'ngResource',
		'ngRoute', 'angularApp.directives', 'angularApp.services',
		// 'angularApp.ViewService', 'angularApp.SearchService',
		'angulartics', 'angulartics.piwik' ]);

//angularApp.constant("siteId", "corporate-controller-bpri")
angularApp.constant("siteId", "etlife")

angularApp.config(function($stateProvider, $routeProvider, $httpProvider) {

	$stateProvider.state('login', {
		url : '/login',
		templateUrl : 'html/loginEtlife.html',
		controller : 'LoginController'

	})
	
	.state('homeEtlife', {
		url : '/homeEtlife',
		templateUrl : 'html/homeEtlife.html',
		controller : 'HomeController'

	})
	
	.state('search', {
		url : '/search?:term',
		templateUrl : 'html/search.html',
		controller : 'SearchController'
	})

	.state('filter-search', {
		url : '/filter-search?:category?:term',
		templateUrl : 'html/filter-search.html',
		controller : 'FilterSearchController'
	})
	.state('filter-searchos', {
		url : '/filter-searchos?:category?:term',
		templateUrl : 'html/filter-searchos.html',
		controller : 'FilterSearchController'
	})
	
	/*.state('filter-searchpa', {
		url : '/filter-searchpa?:category?:term',
		templateUrl : 'html/filter-searchpa.html',
		controller : 'FilterSearchController'

	})
	.state('filter-searchsp', {
		url : '/filter-searchsp?:Sales?:term',
		templateUrl : 'html/filter-searchsp.html',
		controller : 'FilterSearchController'

	})*/
	/*.state('mostRead', {
		url : '/mostRead',
		templateUrl : 'html/mostRead.html',
		controller : 'mostReadController'
		keepOriginalNames: true
	})*/
	
	.state('LCDoc', {
		url : '/LCDoc',
		templateUrl : 'html/lcdoc.html',
		controller : 'LatestCreatedController'
		
	})

	.state('view', {
		url : '/view?:id?:fileName?:author',
		templateUrl : 'html/view.html',
		controller : 'ViewController'
	})
	
	
	

	.state('feedback-report', {
		url : '/admin/feedback-report',
		templateUrl : 'html/admin/feedback-report.html',
		controller : 'FeedbackReportController'
	})

	.state('about', {
		url : '/about',
		templateUrl : 'html/about.html',
		controller : 'AboutController'

	})
	.state('popup', {
		url : '/popup',
		templateUrl : 'html/popup.html',
		controller : 'PopupController'

	})

	$httpProvider.defaults.headers.common['Authorization'] = 'Basic '
			+ btoa(sessionStorage.getItem('token'));
});


/*var PopupDemo=angular.module('PopupDemo').controller('PopupDemoCont', ['$scope','$modal',function ($scope, $modal) {
	$scope.open = function () {
	console.log('opening pop up');
	var modalInstance = $modal.open({
	templateUrl: 'popup.html',
	controller: 'PopupController',
	});
	}
	}]);*/
/*const cors = require('cors');

//app.use(cors());

app.use(cors({
origin: 'http://localhost:9090',
credentials: true
}));*/
/*angularApp.all('', function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "");
	res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
	res.header('Access-Control-Allow-Headers', "Origin, X-Requested-With, Content-Type, Accept, Authorization");
	//Auth Each API Request created by user.
	next();
	});*/
	
