var LoginController = angularApp
		.controller(
				'LoginController',
				function LoginController($scope, $rootScope, $window, $http,
						$location, $state,$stateParams,siteId, UtilService, CommonDataService,
						UserDataService,LatestCreatedService) {
					

					$scope.showBadCredentials = true;

					var clearInputFields = function() {
					}

					var authenticate = function(credentials, callback) {

						var method = 'post';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/authentication/versions/1/tickets";
					
						var body = {
						'userId' : $scope.credentials.username,
						'password' : $scope.credentials.password
						};
					
						UtilService.doAjax(
										method,
										url,
										body,
										function(response) {
											if (response.status === 201) {
												$rootScope.authenticated = true;
												$rootScope.displayUserName = $scope.credentials.username;
											   console.log("response" + response);
												sessionStorage.setItem('token',response.data.entry.id);
												sessionStorage.setItem('userId',response.data.entry.userId);
												
												
												$rootScope.tokenIH=response.data.entry.id;
												//console.log("tocken ",$scope.tokenIH);
												
												
												
											} else {
												$rootScope.authenticated = false;
											}
											callback
													&& callback($rootScope.authenticated);
										});
					}
					
					
					/*$scope.onPopup = function ($scope, $window) {
				           $scope.OpenPopupWindow = function () {
				               $window.open("#mostRead", "popup", "width=300,height=200,left=10,top=150");
				        	   $state.go('mostRead');
				           }
				       }*/
					
					
					// ############### MostRead start

					$scope.LCDoc = function() {

						//alert("Hi, I am in LCDoc with LatestCreatedController");
						var nodeId = $stateParams.id;
						// var commentId = event.target.id;

						var method = 'post';
						// http://localhost:8080/alfresco/s/share-stats/select-audits?type=mostread&module=document&sites=bsg&limit=1000
						var url = UtilService.alfrescoContextRoot()
								  + "/alfresco/api/-default-/public/search/versions/1/search";
								/*+ "/alfresco/s/share-stats/select-audits?type=mostread&module=document&sites="
								+ siteId + "&limit=1000";*/

						var body = {
								"query" : {
									"query" : "SITE:'" + siteId + "' AND (*)", // \"corporate-controller-bpri\"
									"language" : "afts"
								},
								
								/*SELECT * FROM cmis:folder WHERE CONTAINS('PATH:"//app:company_home/st:sites/cm:NameSite/cm:documentLibrary/*"')*/
								"paging" : {
									"maxItems" : 100,
									"skipCount" : 0
								},
								"include" : [ "properties" ],
								/* "path" */
								/* "aspectNames" */
								"filterQueries" : [ {
									"query" : "TYPE:'cm:content'"
								}, {
									"query" : "-cm:creator:system"
								}, {
									"query" : "-TYPE:'fm:post'"
								} ],
								/*
								 * query specific to site here site ref is for c
								 * BPRI site
								 * "ANCESTOR:\"workspace://SpacesStore/9553fe6f-0c15-4996-928c-dc919b30ab13\""
								 * "query" : "cm:creator:username"
								 */
								"sort" : [ {
									"type" : "FIELD",
									/*"field" : "cm:mimeType", commented by sandeep*/
									"field" : "cm:created",
									/*"field" : "cm:modified", commented by sandeep*/
									/*"ascending" : "true"*/
									"ascending" : "false"
								} ],
								'defaults' : {
									'textAttributes' : [ 'cm:content', 'cm:name',
											'cm:description', 'cm:title' ],
									'defaultFTSOperator' : 'OR',
									'defaultFTSFieldOperator' : 'OR',
									'namespace' : 'cm',
									'defaultFieldName' : '\"/\"'
								}
							};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {
							console.log(response);
							if (response.status === 200) {
								console.log('Most Viewed Docs', response);
								console.log("response.length",response.length);
								if (response.data.list.entries.length > 0) {
									var listOfItems = response.data.list.entries;
									
									$scope.allItemsCount = response.data.list.entries.length;
									
									
									
									$rootScope.allItemsDetails = LatestCreatedService.getPropertiesOf(response);
									console.log("$rootScope.allItemsDetails",$rootScope.allItemsDetails[0].by);
									
									
									$rootScope.by=$rootScope.allItemsDetails[0].by;
									$rootScope.idIh=$rootScope.allItemsDetails[0].id;
									$rootScope.nameIh=$rootScope.allItemsDetails[0].name;
									$rootScope.createdOn=$rootScope.allItemsDetails[0].createdOn;
									$rootScope.subCategory=$rootScope.allItemsDetails[0].subCategory;
									$rootScope.displayNameIH=$rootScope.allItemsDetails[0].displayName;
									
								} else {
									console.log('0 items in repository');
								}
							
							} else {
								console.log('status != 200');
							}
						}, function errorCallback(response) {
							console.log('error');
						});
					}

					// ############### MostRead End
					
					
					//$window.open('https://www.google.com', '_blank');
					
					
					

					$scope.onLoginClick = function() {

						console.log("Login Click");
						$scope.credentials.username = document
								.getElementById("username").value;
						$scope.credentials.password = document
								.getElementById("password").value;

						if (document.getElementById("password").value.length > 0) {
							authenticate($scope.credentials,
									function() {
										if ($rootScope.authenticated) {
											console.log("authenticated");
											$rootScope.displayUserName = $scope.credentials.username;
											var redirectUrl = sessionStorage.getItem('redirectUrl');
											if (redirectUrl	&& redirectUrl.indexOf("login") != true
													&& redirectUrl.indexOf("#") == true) {
												/*$state.go('mostRead');*/
												$window.location.href = redirectUrl;
											} else {
												// $state.go('home');
												$state.go('homeEtlife');
												    
												console.log("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
												$scope.LCDoc();
												
												$('#onload').modal('show');
												
											/*	var modalInstance=$modal.open({
													templateUrl: 'lcdoc.html',
														controller:'HomeController'
															
												});
												*/
												
												
												
												
												$scope.commentText = '';
												var commentVar = setTimeout(commentFunc, 20);
												
												function commentFunc() {
													console.log("inside the pop up after dalay__________________");
													//$scope.LCDoc();
												}
												
												
												
												
												
												
											}
										} else {
											console.log("not authenticated");
											$scope.error = "Not authenticated, Incorrect username/password !";
											$state.go('login');
										}
									});
						} else {
							$rootScope.authenticated = false;
						}
						
						
						    
						   
						    
					}

					angular.element(document).ready(function() {		
						$("#headerId").hide();
						console.log("**********LoginController***********");
						console.log("header hidded");
						$scope.credentials = {};
						if (sessionStorage.getItem('token')) {
							$state.go('login');
						}
					});
					
					

				});
