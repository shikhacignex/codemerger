package com.edelweiss.bpri.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.edelweiss.bpri.entity.Feedback;

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, Long> {

	@Query(value = "select  id, created_date, feedback_text, feedback_type, url, username from bpri where created_date >= timestamp :fromDate AND created_date <= timestamp :toDate", nativeQuery = true)
	public List<Feedback> findFromDateToDate(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate);

//	@Query(value = "select id,created_date,feedback_text,feedback_type,url,username from bpri where feedback_type = :s", nativeQuery = true)
//	public List<Feedback> findFromDateToDate(@Param("s") String s); //
	
	

}
