'use strict';

var IndexController = angularApp
		.controller(
				'IndexController',
				function IndexController($scope, $stateParams, $rootScope,
						$state, $http, $location, $window,$route, UserDataService,
						UtilService, ControllerService, siteId,
						CommonDataService,LatestCreatedService) {
					
					 
					$scope.alfrescoContext = UtilService.alfrescoContextRoot();
					$scope.token = sessionStorage.getItem('token');
					
					
				
					$scope.onLogoutClick = function() {
						var method = 'delete';
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/api/-default-/public/authentication/versions/1/tickets/-me-"
						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}
						var body = {};

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						})
								.then(function successCallback(response) {
											console.log("Logged out Successfully with response  : ",response);
											// $http.get(UtilService.contextRoot()
											// + '/logout', {})
											// var data=response.data;
											// console.log("Logged out
											// Successfully ", response.status);
											$rootScope.authenticated = false;
											/*$location.reload();*/
											$location.path("/login");
											$window.location.reload();

										},
										function errorCallback(response) {
											console.log("response  : ",response);
										});
						/*
						 * $http.get(UtilService.contextRoot() + '/login', {})
						 * .success(function () { $rootScope.authenticated =
						 * false; $location.path("/login"); }).error(function
						 * (data) { console.log("Logout failed")
						 * $rootScope.authenticated = false;
						 * $location.path("/login"); });
						 */

					}

				
					
				if ($rootScope.authenticated) {
						$('#overlay').modal('show');
						setTimeout(function() {
							$('#overlay').modal('hide');
						}, 5000);
						$state.go('mostraed');
					}
					/*
					 * if ($rootScope.authenticated) {
					 * $(window).load(function(){ $('#onload').modal('show');
					 * });
					 * 
					 * var n = $(".slider-slide-wrap").length, width = 194,
					 * newwidth = width * n;
					 * 
					 * $('.slide-wrap').css({ 'width': newwidth });
					 * 
					 * $(".slider-slide-wrap").each(function (i) { var thiswid =
					 * 194; $(this).css({ 'left': thiswid * i });
					 * 
					 * }); on scroll move the indicator 'shown' class to the
					 * most visible slide on viewport
					 * 
					 * $('.slider-wrap').scroll(function () { var scrollLeft =
					 * $(this).scrollLeft();
					 * $(".slider-slide-wrap").each(function (i) { var posLeft =
					 * $(this).position().left var w = $(this).width();
					 * 
					 * if (scrollLeft >= posLeft && scrollLeft < posLeft + w) {
					 * $(this).addClass('shown').siblings().removeClass('shown'); }
					 * }); }); on left button click scroll to the previous
					 * sibling of the current visible slide
					 * $('#slider-left').click(function () { var $prev =
					 * $('.slide-wrap .shown').prev();
					 * 
					 * if ($prev.length) { $('.slider-wrap').animate({
					 * scrollLeft: $prev.position().left }, 'slow'); } }); on
					 * right button click scroll to the next sibling of the
					 * current visible slide $('#slider-right').click(function () {
					 * var $next = $('.slide-wrap .shown').next();
					 * 
					 * if ($next.length) { $('.slider-wrap').animate({
					 * scrollLeft: $next.position().left }, 'slow'); } });
					 */

					$scope.onFeedbackSubmitCommentClick = function() {

						// document.getElementById("myModal").close();

						if (sessionStorage.getItem('token')) {
							var text = $scope.feedbackText;
							var feedbackType = $scope.feedbackDropdownSelectedOption.name;
							

							if (text != null || text != undefined || text != ''	|| text != "") {
								var urlOnPage = $location;
								var userId = sessionStorage.getItem('userId');
								var method = 'post';
								var url = UtilService.contextRoot()	+ "/api/feedback";
								text = text.trim();
								var body = {
									"username" : String(userId),
									"url" : String(urlOnPage.$$absUrl),
									"feedbackText" : "'"+ String(text) + "' \r\nFeedback From : " + String(userId),
									"feedbackType" : String(feedbackType)
								};

								var headers = {
									'Content-Type' : 'application/json'
								}

								$http({
									method : method,
									url : url,
									headers : headers,
									data : body
								}).then(function successCallback(response) {
									console.log(response);
									if (response.status === 200) {
										console.log('status 200');
										console.log('response 200:  ',response.data.feedbackText);
										var feed = response.data.feedbackText;
										if(feed != null || feed != undefined || feed != '' || feed !=""){
																						
											$("[data-dismiss=modal]").trigger({ type: "click" });
											//document.getElementById("myForm").reset();
											
											/*$timeout(function () {
												$scope.successMessage = false;
									             window.location = '#/homeEtlife';
									        }, 5000);*/
											
											$scope.feedbackText = null;
											
										}else {
											console.log(' Please enter text');
										}
									} else {
										console.log('status != 200');
									}
								}, function errorCallback(response) {
									console.log('error', response);
								});
							}
							//$scope.feedbackText = '';
							$scope.feedbackDropdownSelectedOption = $scope.feedbackDropdownOptions[0];
							document.getElementById("#myModal");

						} else {
							state.go('.myModel');
						}

						// $scope("#myModel").hide();
						// $('myModel').modal('hide');
						// document.getElementById("#myModal").close();
						//$scope.feedbackText = null;

					}

					$scope.onMainSearchClick = function() {
						var text = $scope.mainSearchText;
						$scope.selectedMenuItem = '';
						$state.go('search', {
							term : text
						});

						$scope.mainSearchText = null;

					}// close of onMainSearchClick()

					/*
					 * var input=$scope.mainSearchId;
					 * 
					 * 
					 * input.addEventListener("keyup", function(event) {
					 * event.preventDefault(); if (event.keyCode === 13) {
					 * console.log("+++++++++++++++++on Enter click");
					 * //document.getElementById("myBtn").click(); } });
					 */

					$scope.myFunct = function(keyEvent) {
						if (keyEvent.which === 13)
							$scope.onMainSearchClick();

						// $scope.mainSearchId = null;

					}

					$scope.onAboutUsClick = function() {

					}

					$scope.onSubscribeClick = function() {

					}

					var initilizeFeedbackDropdown = function() {
						$scope.feedbackDropdownOptions = [ {
							name : "I like something",
							id : 1
						}, {
							name : "I dislike something",
							id : 2
						}, {
							name : "I have a suggestion",
							id : 3
						} ];
						$scope.feedbackDropdownSelectedOption = $scope.feedbackDropdownOptions[0];
					};

					/*
					 * var closeSelf =function(){ // do something
					 * 
					 * if(condition satisfied){ alert("conditions satisfied,
					 * submiting the form.");
					 * document.forms['certform'].submit(); window.close();
					 * }else{ alert("conditions not satisfied, returning to
					 * form"); } }
					 */
					
					//MostRead Start
					
					
					
					
				/*	commented by shikha for code merger
				 var getAllItems = function() {

						var method = 'post';
						var url = UtilService.alfrescoContextRoot()
						+ "/alfresco/api/-default-/public/search/versions/1/search";
						//+ "/alfresco/s/share-stats/select-audits?type=mostread&module=document&sites="
						+ siteId + "&limit=1000";
						var body = {
								"query" : {
									"query" : "SITE:'" + siteId + "' AND (*)", // \"corporate-controller-bpri\"
									"language" : "afts"
								},
								"paging" : {
									"maxItems" : 100,
									"skipCount" : 0
								},
								"include" : [ "properties" ],
								// "path" 
								// "aspectNames" 
								"filterQueries" : [ {
									"query" : "TYPE:'cm:content'"
								}, {
									"query" : "-cm:creator:system"
								}, {
									"query" : "-TYPE:'fm:post'"
								} ],
							
							"sort" : [ {
								"type" : "FIELD",
								//"field" : "cm:mimeType", commented by sandeep
								"field" : "cm:created",
								//"field" : "cm:modified", commented by sandeep
								//"ascending" : "true"
								"ascending" : "false"
							} ],
							'defaults' : {
								'textAttributes' : [ 'cm:content', 'cm:name',
										'cm:description', 'cm:title' ],
								'defaultFTSOperator' : 'OR',
								'defaultFTSFieldOperator' : 'OR',
								'namespace' : 'cm',
								'defaultFieldName' : '\"/\"'
							}
						};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						})
								.then(function successCallback(response) {
											if (response.status === 200) {
												console.log("response",response)
													if (response.data.list.entries.length > 0) {
														var listOfItems = response.data.list.entries;
														
														
														console.log("listOfItems ",listOfItems);
														console.log("listOfItems",listOfItems[0]);
														
														
														
														//console.log("response.length",listOfItems);
														//var segregatedByMime = segregateDataByMimeType(listOfItems);
														//setDetailsOfEachItem(segregatedByMime);
														//$scope.allItemsCount = response.data.items.length;
												} else {
													console.log('0 items in repository');
												}
											} else {
												console.log('response other than 200 status code',response.status);
											}
											$scope.allItemsDetails = LatestCreatedService.getPropertiesOf(response);
											console.log("allItemsDetails ",$scope.allItemsDetails);
											
											
											
										}, function errorCallback(response) {
											console.log('error');
											$state.go('login');
										});

					}
					*/
					//MostRead End
					
					
					/*$scope.mostReadOnClick = function() {

						// alert("I am inside the SalesProductsOnclick");
						$state.go('mostRead', {
							term : 'mostReadOnClick'
						});
					}
					*/
					
					//Shreyas
					var init = function() {
						getAllItems();
						var id = $stateParams.id;
						var fileName = $stateParams.fileName;
						var author = $stateParams.author;
						$scope.author = $stateParams.author;

						if (id === null || id === undefined || id === '') {
							$state.go('homeEtlife');
						} else {
							$.ajax({

							    url : UtilService.alfrescoContextRoot()	+ "/alfresco/api/-default-/public/alfresco/versions/1/nodes/" + id,
							    type : 'GET',
							    xhrFields: {
							        'withCredentials': true //Tell browser to provide credentials
							    },
							    //data: payload,
							    //crossDomain: true,
							    success : function(response) {
							    alert("successby shikha");
							    	console.log("shikha"+JSON.stringify(response));
							    	$scope.likeStatus = true;

									var createdDate = (new Date(response.entry.createdAt)).toDateString().split(" ");
										
									if(response.entry.properties["etm:Product"]){
										var subCategory = response.entry.properties["etm:Product"];
										$scope.subCategorycopy = response.entry.properties["etm:Product"];
									}else if(response.entry.properties["etm:Marketing"]){
										var subCategory = response.entry.properties["etm:Marketing"];
										$scope.subCategorycopy = response.entry.properties["etm:Marketing"];
									}else if(response.entry.properties["etm:Actuarial"]){
										var subCategory = response.entry.properties["etm:Actuarial"];
										$scope.subCategorycopy = response.entry.properties["etm:Actuarial"];
									}else if(response.entry.properties["etm:Sales"]){	
										var subCategory = response.entry.properties["etm:Sales"];
										$scope.subCategorycopy = response.entry.properties["etm:Sales"];
									} else if(response.entry.properties["etm:OperationsAndServices"]){
										var subCategory = response.entry.properties["etm:OperationsAndServices"];
										$scope.subCategorycopy = response.entry.properties["etm:OperationsAndServices"];
									}else if(response.entry.properties["etm:Investments"]){
										var subCategory = response.entry.properties["etm:Investments"];
										$scope.subCategorycopy = response.entry.properties["etm:Investments"];
									}else if(response.entry.properties["etm:AdminAndFacilities"]){
										var subCategory = response.entry.properties["etm:AdminAndFacilities"];
										$scope.subCategorycopy = response.entry.properties["etm:AdminAndFacilities"];
									}else if(response.entry.properties["etm:RiskManagement"]){
										var subCategory = response.entry.properties["etm:RiskManagement"];
										$scope.subcopy = response.entry.properties["etm:RiskManagement"];
									}else if(response.entry.properties["etm:Finance"]){
										var subCategory = response.entry.properties["etm:Finance"];
										$scope.subCategorycopy = response.entry.properties["etm:Finance"];
									}else if(response.entry.properties["etm:HRPolicy"]){
										var subCategory = response.entry.properties["etm:HRPolicy"];
										$scope.subCategorycopy = response.entry.properties["etm:HRPolicy"];
									}else if(response.entry.properties["etm:InformationTechnology"]){
										var subCategory = response.entry.properties["etm:InformationTechnology"];
										$scope.subCategorycopy = response.entry.properties["etm:InformationTechnology"];
									}else if(response.entry.properties["etm:LegalAndCompliance"]){
										var subCategory = response.entry.properties["etm:LegalAndCompliance"];
										$scope.subCategorycopy = response.entry.properties["etm:LegalAndCompliance"];
									}

										var description = response.entry.properties["cm:description"];

										var dayAndMonth = new Array();
										dayAndMonth
												.push({
													"day" : createdDate[2],
													"month" : createdDate[1],
													"year" : createdDate[3]
												});

										setDetails(id, fileName,
												$scope.author,
												description,
												dayAndMonth);

										previewDocument(id,
												fileName);

										getMoreBestPractices(id,
												fileName);

										//getAllLikes(id);
										getAllComments(id);
									
							    },
							    error : function(request,error)
							    {
							    	console.log('error');
							    }
							  });
						}
					}
//Shreyas
					
					var getAllItems = function() {

						var nodeId = $stateParams.id;

						var payload = {'cmisaction': "query", 
							       'statement': "SELECT * FROM cmis:document WHERE  CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') ORDER BY cmis:creationDate DESC",
							       'maxItems':100,
							       'skipCount':0,};
				    
						$.ajax({

					    url : UtilService.alfrescoContextRoot() + '/alfresco/api/-default-/public/cmis/versions/1.1/browser',
					    type : 'POST',
					    xhrFields: {
					        'withCredentials': true //Tell browser to provide credentials
					    },
					    data: payload,
					    crossDomain: true,
					    success : function(data) {			
					    	
							if (data.results.length > 0) {
								
								    var listOfItems = data.results;
									
								} else {
									console.log('0 items in repository');
								}
								
							$scope.allItemsDetails = LatestCreatedService.getCmisPropertiesOf(data);
												    	
					    },
					    error : function(request,error)
					    {
					    	console.log('error');
							$state.go('login');
					    }
					  });

					}
					
					// end by shkha
					
					$scope.onMostViewedClick = function() {
												
					
						$("[data-dismiss=modal]").trigger({ type: "click" });
				
						
						//$window.open('http://localhost:9090/#/view?id=2ade8895-cc12-4473-bcc6-06fd8b51e6ee&fileName=kerberos%20Configuration.txt&author=SandyReddy', '_self');
						console.log("inside onMostViewedClick");
						
					}
					
					
				

					$scope.initApp = function() {
						
						initilizeFeedbackDropdown();
						// commented by shikha
						//getAllItems();
						

					};

					angular
							.element(document)
							.ready(
								function() {
									$(this).scrollTop(0);
									init();
//										console
//												.log("**********IndexController*******");
//
//										if ($rootScope.authenticated) {
//											sessionStorage.setItem(
//													'redirectUrl', $location
//															.absUrl());
//											$scope.showSessionExpired();
//											$scope.initApp();
//										} else {
//											ControllerService
//													.checkIfAlreadyAuthenticated(function() {
//														// $scope.selectedMenuItem
//														// = 'Products';
//														if ($rootScope.authenticated) {
//															sessionStorage
//																	.setItem(
//																			'redirectUrl',
//																			$location
//																					.absUrl());
//															$scope.initApp();
//
//														} else {
//															sessionStorage
//																	.setItem(
//																			'redirectUrl',
//																			$location
//																					.absUrl());
//															$scope.initApp();
//															$state.go('login');
//														}
//													});
//										}
									});

				});