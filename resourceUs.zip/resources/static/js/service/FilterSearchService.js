angularApp
		.service(
				'FilterSearchService',
				function($http, UtilService, siteId,$rootScope) {

					this.getPropertiesOf = function(docType) {
						var details = new Array();
						for (var i = 0; i < docType.length; i++) {
							var doc = docType[i];
							doc = doc.entry;
							console.log("item", doc);
							console.log("item", doc.name);
							var createdDate = (new Date(doc.createdAt)).toDateString().split(" ");
							console.log("createdDate:",createdDate);
							var dayAndMonth = new Array();
							dayAndMonth.push({
										"day" : createdDate[2],
										"month" : cscope
										reatedDate[1],
										"year" : createdDate[3]
									});
							console.log("dayAndMonth",dayAndMonth);

							if (doc) {

								details.push({
											"displayName" : doc.name.slice(0,
													doc.name.lastIndexOf(".")),
											"name" : doc.name,
											"by" : doc.properties["cm:author"] ? doc.properties["cm:author"]
													: '',
											"description" : doc.properties["cm:description"] ? doc.properties["cm:description"]
													: '',
											/*"category" : doc.properties["edcc:Theme"] ? doc.properties["edcc:Theme"]
													: '',*/
											"subCategory" : doc.properties["etm:Product"] ? doc.properties["etm:Product"]
											: ''|| doc.properties["etm:Marketing"] ? doc.properties["etm:Marketing"]
											: ''|| doc.properties["etm:Actuarial"] ? doc.properties["etm:Actuarial"]
											: ''|| doc.properties["etm:Sales"] ? doc.properties["etm:Sales"]
											: ''|| doc.properties["etm:OperationsAndServices"] ? doc.properties["etm:OperationsAndServices"]
											: ''|| doc.properties["etm:Investments"] ? doc.properties["etm:Investments"]
											: ''|| doc.properties["etm:AdminAndFacilities"] ? doc.properties["etm:AdminAndFacilities"]
											: ''|| doc.properties["etm:RiskManagement"] ? doc.properties["etm:RiskManagement"]
											: ''|| doc.properties["etm:Finance"] ? doc.properties["etm:Finance"]
											: ''|| doc.properties["etm:HRPolicy"] ? doc.properties["etm:HRPolicy"]
											: ''|| doc.properties["etm:InformationTechnology"] ? doc.properties["etm:InformationTechnology"]
											: ''|| doc.properties["etm:LegalAndCompliance"] ? doc.properties["etm:LegalAndCompliance"]
											: '',
											/*"sbu" : doc.properties["edcc:sbu"] ? doc.properties["edcc:sbu"]
													: '',*/
											"createdOn" : dayAndMonth[0].day +" "+dayAndMonth[0].month+" "+dayAndMonth[0].year
													,
											"id" : doc.id
										});
							}
						}
						console.log("detailsArray : ", details);
						return details;
					}

					// added by shikha for code merger
					this.getCmisFilteredDocuments = function(searchTerm,categoryFilter, callback) {


						// generating the search term and passing this term in
						// the search API
						// alert(searchTerm + " " + categoryFilter);
						// alert($rootScope.currentAspect+ " "+categoryFilter);
						
						// Removed site condition as it caused issues
						// CONTAINS('PATH:\"/app:company_home/st:sites/cm:etlife/cm:documentLibrary//*\"') AND
						var payload = {'cmisaction': "query", 
							       'statement': "SELECT * FROM etm:"+$rootScope.currentAspect+" WHERE etm:"+$rootScope.currentAspect+" = \'"+categoryFilter+"\' ORDER BY cmis:lastModificationDate DESC",
							       'maxItems':100,
							       'skipCount':0,};
				    
						$.ajax({

					    url : 'http://edelbsgcorpuat1.edelcap.com:8080/alfresco/api/-default-/public/cmis/versions/1.1/browser',
					    type : 'POST',
					    xhrFields: {
					        'withCredentials': true //Tell browser to provide credentials
					    },
					    data: payload,
					    crossDomain: true,
					    success : function(data) {			
					    	
									callback(data);
					    	
					    },
					    error : function(request,error)
					    {
					    	console.log('error');
							$state.go('login');
					    }
					  });

					}
					//end by shikha
					
					this.createSearchTerm = function(term) {
						var searchTerm
						searchTerm = '\"' + term
								/*+ '\" OR etl:ProductsAndMarketing:\"' + term*/
								/*+ '\" OR cm:name:\"' + term
								+ '\" OR cm:title:\"' + term
								+ '\" OR cm:description:\"' + term
								+ '\" OR cm:content:\"' + term*/

						var splitTerm = term.split(/\s+/);
						for (var j = 0; j < splitTerm.length; j++) {
							searchTerm = searchTerm + ' OR \"' + splitTerm[j]
									//+ '\" OR etl:ProductsAndMarketing:\"' + splitTerm[j]
									/*+ '\" OR cm:name:\"' + splitTerm[j]
									+ '\" OR cm:title:\"' + splitTerm[j]
									+ '\" OR cm:description:\"' + splitTerm[j]
									+ '\" OR cm:content:\"' + splitTerm[j]*/
									+ '\"';
						}
						return searchTerm;
					}

					this.getFilteredDocuments = function(searchTerm,categoryFilter, callback) {

						// generating the search term and passing this term in
						// the search API
						
						if (categoryFilter === 'Policies') {	
						
							console.log("Polices Match");			
							
						
						var term = '';

						if (searchTerm == '*') {
							term = '*';
						} else {
							term = this.createSearchTerm(searchTerm);
						}

						var method = 'post';
						var url = UtilService.alfrescoContextRoot()+ "/alfresco/api/-default-/public/search/versions/1/search";
						var body = {
							"query" : {
								"query" : "SITE:'" + siteId + "' AND (" + term
										+ ")",
								"language" : "afts"
							},
							"paging" : {
								"maxItems" : 100,
								"skipCount" : 0
							},
							"include" : [ "properties" ],
							"filterQueries" : [
									{
										"query" : "TYPE:'cm:content'"
									},
									{
										"query" : "-cm:creator:system"
									},
									{
										"query" : "-TYPE:'fm:post'"
									},
									{
										"query" : "etm:Product:'"+ categoryFilter + "' ||"
										 +"etm:Marketing:'"+ categoryFilter + "' ||"
										 +"etm:Actuarial:'"+ categoryFilter + "' ||"
										 +"etm:Sales:'"+ categoryFilter + "' ||"
										 +"etm:Investments:'"+ categoryFilter + "' ||"
										 +"etm:AdminAndFacilities:'"+ categoryFilter + "' ||"
										 +"etm:RiskManagement:'"+ categoryFilter + "' ||"
										 +"etm:Finance:'"+ categoryFilter + "' ||"
										 +"etm:HRPolicy:'"+ categoryFilter + "' ||"
										 +"etm:InformationTechnology:'"+ categoryFilter + "' ||"
										 +"etm:LegalAndCompliance:'"+ categoryFilter + "'"
									}
									
									/*,
									{
										"query" : "etl:Actuarial:'"
												+ categoryFilter + "'"
									}*/],
									
									"sort" : [ {
										"type" : "FIELD",
										/*"field" : "cm:mimeType",*/
										"field" : "cm:created",
										"field" : "cm:modified",
										/*"ascending" : "true"*/
										"ascending" : "false"
									} ],
									
							'defaults' : {
								'textAttributes' : [ 'cm:content', 'cm:name',
										'cm:description', 'cm:title' ],
								'defaultFTSOperator' : 'OR',
								'defaultFTSFieldOperator' : 'OR',
								'namespace' : 'cm',
								'defaultFieldName' : '\"/\"'
							}
						};

						var headers = {
							authorization : "Basic " + btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {
							if (response.status === 200) {
								var entries = response.data.list.entries;
								callback(entries);
							} else {
								callback("error");
							}
						}, function errorCallback(response) {
							console.log(response);
							callback("error");
						});
						
						
						
						
						}else{
							
							
							console.log("Else Polices Match");
							
							
							var term = '';

							if (searchTerm == '*') {
								term = '*';
							} else {
								term = this.createSearchTerm(searchTerm);
							}

							var method = 'post';
							var url = UtilService.alfrescoContextRoot()+ "/alfresco/api/-default-/public/search/versions/1/search";
							var body = {
								"query" : {
									"query" : "SITE:'" + siteId + "' AND (" + term
											+ ")",
									"language" : "afts"
								},
								"paging" : {
									"maxItems" : 100,
									"skipCount" : 0
								},
								"include" : [ "properties" ],
								"filterQueries" : [
										{
											"query" : "TYPE:'cm:content'"
										},
										{
											"query" : "-cm:creator:system"
										},
										{
											"query" : "-TYPE:'fm:post'"
										},
										{
											"query" : "etm:Product:'"+ categoryFilter + "' ||"
											 +"etm:Marketing:'"+ categoryFilter + "' ||"
											 +"etm:Actuarial:'"+ categoryFilter + "' ||"
											 +"etm:Sales:'"+ categoryFilter + "' ||"
											 +"etm:OperationsAndServices:'"+ categoryFilter + "' ||"
											 +"etm:Investments:'"+ categoryFilter + "' ||"
											 +"etm:AdminAndFacilities:'"+ categoryFilter + "' ||"
											 +"etm:RiskManagement:'"+ categoryFilter + "' ||"
											 +"etm:Finance:'"+ categoryFilter + "' ||"
											 +"etm:HRPolicy:'"+ categoryFilter + "' ||"
											 +"etm:InformationTechnology:'"+ categoryFilter + "' ||"
											 +"etm:LegalAndCompliance:'"+ categoryFilter + "'"
										}
										
										/*,
										{
											"query" : "etl:Actuarial:'"
													+ categoryFilter + "'"
										}*/],
										
										"sort" : [ {
											"type" : "FIELD",
											/*"field" : "cm:mimeType",*/
											"field" : "cm:created",
											"field" : "cm:modified",
											/*"ascending" : "true"*/
											"ascending" : "false"
										} ],
										
								'defaults' : {
									'textAttributes' : [ 'cm:content', 'cm:name',
											'cm:description', 'cm:title' ],
									'defaultFTSOperator' : 'OR',
									'defaultFTSFieldOperator' : 'OR',
									'namespace' : 'cm',
									'defaultFieldName' : '\"/\"'
								}
							};

							var headers = {
								authorization : "Basic " + btoa(sessionStorage.getItem('token'))
							}

							$http({
								method : method,
								url : url,
								headers : headers,
								data : body
							}).then(function successCallback(response) {
								if (response.status === 200) {
									var entries = response.data.list.entries;
									callback(entries);
								} else {
									callback("error");
								}
							}, function errorCallback(response) {
								console.log(response);
								callback("error");
							});
							
							
							
							
							
							
							
							
							
						}//getFilteredDocuments close
						
						
						
						
						
						
					}
				})
