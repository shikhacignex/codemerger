package com.edelweiss.bpri.mailsender;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.mail.internet.InternetAddress;

public class EmailService 
{
	InternetAddress[] recipientAddress;

	public void readPropertyFile() {
		
		try {
			
			FileReader reader = new FileReader("C:\\resources\\mail.properties");
			Properties props = new Properties();
			props.load(reader);
			Set<Object> keySet = props.keySet();
			
			 recipientAddress = new InternetAddress[keySet.size()-2];
			 int counter = 0;
			for (Object s : keySet) {
				String key = (String) s;
				System.out.println("keys+++" + key);
				String toemailValues = props.getProperty(key);
				
				if ((!(key.equalsIgnoreCase("username")) && (!(key.equalsIgnoreCase("password"))))) {
					System.out.println("to adresses added to InternetAdress are ++++++" + toemailValues.trim());
					recipientAddress[counter] = new InternetAddress(toemailValues.trim());
					counter++;

				} // close of if

			} // close of for
			
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		

	}// close of readPropertyFile

	public InternetAddress[] getRecipientAddress() {
		return recipientAddress;
	}

	public void setRecipientAddress(InternetAddress[] recipientAddress) {
		this.recipientAddress = recipientAddress;
	}

	public static void main(String[] args) {

		EmailService service = new EmailService();
		service.readPropertyFile();

	}

}
