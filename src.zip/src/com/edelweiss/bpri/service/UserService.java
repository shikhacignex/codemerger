package com.edelweiss.bpri.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edelweiss.bpri.dao.UserRepository;
import com.edelweiss.bpri.entity.User;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;

	public boolean getUser(String userName) {
		User user = userRepository.findByUserNameIgnoreCase(userName);
		boolean isAdmin = false;
		if (user != null && user.isAdmin()) {
			isAdmin = true;
		}
		return isAdmin;
	}

}
