'use strict';

var mostReadController = angularApp.controller('mostReadController',
				function mostReadController($scope,$http, $state, $stateParams,
						$rootScope, $location, mostReadService,siteId,UtilService) {

					$scope.alfrescoContext = UtilService.alfrescoContextRoot();
					$scope.token = sessionStorage.getItem('token');
					/*$scope.filterValue = 'Products';
					$scope.filterPAValue = 'Reporting And Modelling';
					$scope.filterSPValue = 'Organic Agency';*/
					
					
					$scope.loadIndexDocument = 4;

					// function to increase visible items
					$scope.ViewMore = function(item) {
						// don't increment if at the end of the list
						if (item === 'document') {
							if ($scope.loadIndexDocument < $scope.documentCount) {
								$scope.loadIndexDocument += 4;
								if ($scope.loadIndexDocument >= $scope.documentCount) {
									$("#docViewButton").addClass("disable-view-more-button");
								}
							}
						}

					};
					
					// ############### MostRead start

					$scope.mostRead = function() {

						alert("Hi, I am in MostRead with IndexController");
						var nodeId = $stateParams.id;
						// var commentId = event.target.id;

						var method = 'GET';
						// http://localhost:8080/alfresco/s/share-stats/select-audits?type=mostread&module=document&sites=bsg&limit=1000
						var url = UtilService.alfrescoContextRoot()
								+ "/alfresco/s/share-stats/select-audits?type=mostread&module=document&sites="
								+ siteId + "&limit=1000";

						var body = {};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						}).then(function successCallback(response) {
							console.log(response);
							if (response.status === 200) {
								console.log('Most Viewed Docs', response);
								console.log("response.length",response.length);
								if (response.data.items.length > 0) {
									var listOfItems = response.data.items;
									var segregatedByMime = segregateDataByMimeType(listOfItems[0]);
									setDetailsOfEachItem(segregatedByMime);
									$scope.allItemsCount = response.length;
									
									
									if (searchTerm != '*') {
										$scope.searchTerm = searchTerm	+ " in ";
									}
									$scope.allItemsDetails = mostReadService.getPropertiesOf(response);
								} else {
									console.log('0 items in repository');
								}
							
							} else {
								console.log('status != 200');
							}
						}, function errorCallback(response) {
							console.log('error');
						});
					}

					// ############### MostRead End
					
										
					//start properties
					
					var getPropertiesOf = function(docType) {
						var details = new Array();
						for (var i = 0; i < docType.length; i++) {
							 var doc = response.data.items; 
							doc = docType[i];
							
							if (doc.name != null || doc.properties != null
									|| doc.id != null || doc.name != undefined
									|| doc.properties != undefined
									|| doc.id != undefined || doc.name != ''
									|| doc.properties != '' || doc.id != '') {

								details.push({
											"displayName" : doc.name.slice(0,
													doc.name.lastIndexOf(".")),
											"name" : doc.name,
											"by" : doc.properties["cm:author"] ? doc.properties["cm:author"]
													: '',
											"description" : doc.properties["cm:description"] ? doc.properties["cm:description"]
													: '',
											/*"category" : doc.properties["edcc:Theme"] ? doc.properties["edcc:Theme"]
													: '',*/
											"subCategory" :  doc.properties["etl:ProductsAndMarketing"] ? doc.properties["etl:ProductsAndMarketing"]
											: ''|| doc.properties["etl:Actuarial"] ? doc.properties["etl:Actuarial"]
											: ''|| doc.properties["etl:Sales"] ? doc.properties["etl:Sales"]
											: ''|| doc.properties["etl:OperationsAndServices"] ? doc.properties["etl:OperationsAndServices"]
											: ''|| doc.properties["etl:InvestmentManagement"] ? doc.properties["etl:InvestmentManagement"]
											: ''|| doc.properties["etl:AdminAndFacilities"] ? doc.properties["etl:AdminAndFacilities"]
											: ''|| doc.properties["etl:RiskManagement"] ? doc.properties["etl:RiskManagement"]
											: ''|| doc.properties["etl:Finance"] ? doc.properties["etl:Finance"]
											: ''|| doc.properties["etl:HumanResources"] ? doc.properties["etl:HumanResources"]
											: ''|| doc.properties["etl:InformationTechnology"] ? doc.properties["etl:InformationTechnology"]
											: ''|| doc.properties["etl:LegalAndCompliance"] ? doc.properties["etl:LegalAndCompliance"]
											: '',
											
											/*"sbu" : doc.properties["edcc:sbu"] ? doc.properties["edcc:sbu"]
													: '',*/
											"id" : doc.id
										});
							}
						}
						return details;
					}
					
					//end properties
					/*var setDetailsOfEachItem = function(segregatedByMime) {
						// count set on UI
						$scope.presentationCount = segregatedByMime.presentation.length;
						$scope.videoCount = segregatedByMime.video.length;
						$scope.documentCount = segregatedByMime[0].document.length;

						// setting all data in a variable
						$scope.presentationDetails = getPropertiesOf(segregatedByMime.presentation);
						$scope.videoDetails = getPropertiesOf(segregatedByMime.video);
						$scope.documentDetails = getPropertiesOf(segregatedByMime.document);
					}*/

					/*var segregateDataByMimeType = function(listOfItems) {
						var segregatedByMime = new Array();
						var presentation = new Array();
						var video = new Array();
						var document = new Array();

						for (var i = 0; i < listOfItems.length; i++) {
							var data = listOfItems[i];
							if (data.popularity != undefined || popularity != '') {										
									document.push(data);
							}
						}
						segregatedByMime.push({
							"presentation" : presentation,
							"video" : video,
							"document" : document
						});
						return segregatedByMime;
					}*/
					var getAllItems = function() {

						var method = 'get';
						var url = UtilService.alfrescoContextRoot()
						+ "/alfresco/s/share-stats/select-audits?type=mostread&module=document&sites="
						+ siteId + "&limit=1000";
						var body = {
							
							/*"sort" : [ {
								"type" : "FIELD",
								"field" : "cm:mimeType", commented by sandeep
								"field" : "cm:created",
								"field" : "cm:modified", commented by sandeep
								"ascending" : "true"
								"ascending" : "false"
							} ],
							'defaults' : {
								'textAttributes' : [ 'cm:content', 'cm:name',
										'cm:description', 'cm:title' ],
								'defaultFTSOperator' : 'OR',
								'defaultFTSFieldOperator' : 'OR',
								'namespace' : 'cm',
								'defaultFieldName' : '\"/\"'
							}*/
						};

						var headers = {
							authorization : "Basic "
									+ btoa(sessionStorage.getItem('token'))
						}

						$http({
							method : method,
							url : url,
							headers : headers,
							data : body
						})
								.then(function successCallback(response) {
											if (response.status === 200) {
												console.log("response",response)
													if (response.data.items.length > 0) {
														var listOfItems = response.data.items;
														
														
														console.log("listOfItems ",listOfItems);
														console.log("listOfItems",listOfItems[0]);
														
														
														
														//console.log("response.length",listOfItems);
														/*var segregatedByMime = segregateDataByMimeType(listOfItems);
														setDetailsOfEachItem(segregatedByMime);
														$scope.allItemsCount = response.data.items.length;*/
												} else {
													console.log('0 items in repository');
												}
											} else {
												console.log('response other than 200 status code',response.status);
											}
											$scope.allItemsDetails = mostReadService.getPropertiesOf(response);
											console.log("allItemsDetails ",$scope.allItemsDetails);
											
											
											
										}, function errorCallback(response) {
											console.log('error');
											$state.go('login');
										});

					}
					
					
					
					
					

					var init = function() {
						getAllItems();
						
						}

					angular.element(document).ready(
									function() {
										alert("mostReadController");
										console.log("**********mostReadController*******");
										$(this).scrollTop(0);

										if (sessionStorage.getItem('token')) {
											//$scope.selectedMenuItem = 'Products';
											init();
										} else {
											sessionStorage.setItem('redirectUrl', $location.absUrl());
											console.log("mostRead Unauthenticated");
											$state.go('login');
										}
									});

					

				})