package com.edelweiss.bpri.mailsender;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

@org.springframework.stereotype.Service
public class SendEmail {

	protected static final String host = "zmail.edelcap.com";
	protected String to = null;
	
	protected static String user = null;
	protected static String password = null;
	
	protected Session session = null;

	EmailService emailService=new EmailService();
	
	
	// Get the session object
	/*
	 * Method for sending the mail. feedbackText is a variable which accepts message
	 * body as String
	 */
	public void sendmail(String feedbackType,String feedbackText) {
		try {
			emailService.readPropertyFile();
			InternetAddress[] recipientAddress = emailService.getRecipientAddress();
			FileReader reader = new FileReader("C:\\resources\\mail.properties");
			//FileReader reader = new FileReader("resources/mail.properties");
			Properties props = new Properties();
			props.load(reader);
			user = props.getProperty("username");
			password = props.getProperty("password");
			to = props.getProperty("toaddress");
			System.out.println("UserName:  " + user);
			//System.out.println("Password: " + password);

			props.put("mail.smtp.host", host);
			
			props.put("mail.smtp.auth", "true");

			session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(user.trim().toString(), password.trim().toLowerCase());
				}
			});
		
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(user));
			//message.addRecipient(Message.RecipientType.TO, new InternetAddress(to.toString()));
			message.setRecipients(MimeMessage.RecipientType.TO, recipientAddress);
			
			message.setSubject("Feedback :- "+ feedbackType.toString());
			message.setText(feedbackText.toString());

			// send the message
			//Transport.send(message);
			
			
			Transport transport = session.getTransport("smtp");
			transport.connect(host, user, password);
			message.saveChanges();
			transport.sendMessage(message, message.getAllRecipients());
			
			
			
			
			
			

			System.out.println("message sent successfully...");

		} catch (MessagingException e) {
			e.printStackTrace();
		}catch (FileNotFoundException f) {
			f.printStackTrace();
		} catch (IOException i) {
			i.printStackTrace();
		}

	}// close of sendmail

}// close of SendEmail
